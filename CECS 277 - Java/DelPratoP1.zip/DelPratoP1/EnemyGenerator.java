import java.io.File;
import java.io.FileNotFoundException;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/** 
 * Creates an array list of all the enemys the game has to offer.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class EnemyGenerator {
    
    private ArrayList<Enemy> enemyList; //The array list that holds all the monsters
    private ItemGenerator ig;           //variable tied to the item generator
    
    /**
     * Class default constructor. Will read in from a file all the monsters for the game.
     * @param ig Passes in the item generator
     */
    public EnemyGenerator( ItemGenerator ig ){
        this.enemyList = new ArrayList<>();     //Initializes the enemy list
        String input;                           //Used to save file input
        String[] inputSplit;                    //Used to split the input so it can read mutiple values per line
        
        try{
            //Calls a scanner to read the input file
            Scanner readFile = new Scanner( new File( "EnemyList.txt" ) );
            
            //Will read the file until it is empty
            do{
                //Reads in a line of the input file and splits at the ',' into a string array
                input = readFile.nextLine();
                inputSplit = input.split( "," );
                
                //If the last character on the line is equal to a physical monster it will create a regular enemy
                if( inputSplit[3].equals( "p" ) ){
                    //Creates new enemey and reads in the name, war cry, level, hp, and generates a new item 
                    //and then adds it to the enemylist. parses the int so it can be converted
                    Enemy newEnemy = new Enemy( inputSplit[0], inputSplit[1], 1, 
                                                parseInt( inputSplit[2] ), ig.generateItem() );
                    enemyList.add( newEnemy );
                }
                else{
                    //If not a physical enemy, a new magical enemy will be created and read in the same data
                    MagicalEnemy newEnemy = new MagicalEnemy( inputSplit[0], inputSplit[1], 1, 
                                                              parseInt( inputSplit[2] ), ig.generateItem() );
                    enemyList.add(newEnemy);
                }
               
            }while( readFile.hasNext() );
            
            //closes the file
            readFile.close();
        }catch( FileNotFoundException fnf ){
            //throws an exception if the file not found
            System.out.println("File was not found");
        }
    }
    
    /**
     * Randomly generates an enemy from the array list and sets its attributes.
     * @param level     takes in the value of the hero
     * @return          returns the enemy
     */
    public Enemy generateEnemy( int level ){
        //randomly picks an enemy from the list
        Random randEnemy = new Random();
        int index = randEnemy.nextInt( enemyList.size() );
        
        //Creates the new hp based on the level of the hearo
        int newHp = ( enemyList.get( index ).getHp() ) * level;
        
        //Increases the max hp and heals the monster to full health
        enemyList.get( index ).increaseMaxHP( newHp - enemyList.get( index ).getMaxHp() );
        enemyList.get( index ).heal( newHp - enemyList.get( index ).getHp() );
        
        return enemyList.get( index );
    }
}
