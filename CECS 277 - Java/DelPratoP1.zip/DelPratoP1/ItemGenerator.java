import java.io.File;
import java.io.FileNotFoundException;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/** 
 * Reads in from a file to fill an array list of items and generates a new item.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class ItemGenerator {
    private ArrayList<Item> itemList;   //used to store the item list
    
    /**
     * Class ItemGenerator default constructor. It will initialize the class variables 
     * and read in from the file and save the contents of the file into the array list.
     */
    public ItemGenerator(){
        this.itemList = new ArrayList<>();  //Initializes the array list
        String input;                       //Used to save file input
        String[] inputSplit;                //Used to split the input so it can read mutiple values per line
        
        try{
            //Calls a scanner to read the input file
            Scanner readFile = new Scanner( new File( "ItemList.txt" ) );
            
            //Will read the file until it is empty
            do{
                //Reads in a line of the input file and splits at the ',' into a string array
                input = readFile.nextLine();
                inputSplit = input.split( "," );
              
                //creates a new item with the name and the value from the file 
                //and then adds it to the array list. also uses parse int to turn the string into an integer.
                Item newItem = new Item( inputSplit[0], parseInt( inputSplit[1] ) );
                itemList.add( newItem );
               
            }while( readFile.hasNext() );
            
            //closes the file
            readFile.close();
        }catch( FileNotFoundException fnf ){
            //throws an exception if file not found
            System.out.println("File was not found");
        }
    }
    
    /**
     * Will randomly generate a new item.
     * @return returns that randomly generated item
     */
    public Item generateItem(){
        //Determines a random number based on the size of the array and return 
        //the item at the random index
        Random randItem = new Random();
        int index = randItem.nextInt( itemList.size() );
        
        return itemList.get( index );
    }
    
    /**
     * Returns the health potion.
     * @return returns the health potion to the calling method
     */
    public Item getPotion(){
        //Searches the array list for the potion and returns it. 
        //else or returns the item at the zero index.
        for( int i = 0; i < itemList.size(); i++ ){
            if( itemList.get( i ).getName().equals( "Health Potion" ) ){
                return itemList.get( i );
            }
        }
        return itemList.get( 0 );
    }  
}