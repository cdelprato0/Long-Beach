import java.util.ArrayList;
import java.util.Random;

/** 
 * Create a program that allows a user to play a dungeon maze game.
 * The dungeon maps, the item list, and the enemy list are all read in from text files and 
 * stored in their respective class
 * When the game starts, the hero is level 1 and begins at the start position of the first map.  
 * Display a covered map to the user and have a marker to show where the hero is located.  
 * Allow the user to choose a direction (North, South, East, or West) to explore the map.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class main {
    
    /**
     * The monster Room. This room will determine if the player wants to fight or run away.
     * if the user wants to run away, it will randomly put them into a different room.
     * 
     * @param h     Passes in the hero object
     * @param m     passes in the map object
     * @param eg    passes in the enemy generator object
     * @return      returns if the fight happen, true or if it didnt, false
     * 
     */
    static boolean monsterRoom( Hero h, Map m, EnemyGenerator eg ){
        Enemy newEnemy = eg.generateEnemy( h.getLevel() );  //Creates a new emeny
        boolean isRoomCleared;                              //is the room cleared or did they run away
        
        //Outputs the monster they encounted
        System.out.println("You've encountered a " + newEnemy.getName());
        newEnemy.display();
        
        //runs the fight method that will determine if they are going to fight 
        //or the hero is going to run away
        isRoomCleared = fight( h, newEnemy );
        
        //If the hero fought and won the battle it will set the room to cleared
        if( isRoomCleared ){
            isRoomCleared = true;
        }
        //If not then the hero ran away and a monster is still in the room
        //It will randomly run away in a vaild direction
        else{
            Random randDir = new Random();  //creates a random varaible
            int direction;                  //used to hold the random value

            //reveals the location so that the user knows the monster is still there 
            //and sets the room to not cleared
            m.reveal(h.getLocation());
            isRoomCleared = false;
            
            //Checks for valid room to run into. If hero is in top left corner. 
            //Randomly chooses a direction and goes to that room.
            if( h.getLocation().x == 0 && h.getLocation().y == 0 ){
                direction = randDir.nextInt( 2 ) + 1;

                switch( direction ){
                    case 1:
                        h.goSouth();
                        break;
                    case 2:
                        h.goEast();
                        break;
                    default:
                        break;      
                }   
            }
            //Checks for valid room to run into. If hero is in top right corner. 
            //Randomly chooses a direction and goes to that room.
            else if( h.getLocation().x == 0 && h.getLocation().y == 4 ) {
                direction = randDir.nextInt( 2 ) + 1;

                switch( direction ){
                    case 1:
                        h.goSouth();
                        break;
                    case 2:
                        h.goWest();
                        break;
                    default:
                        break;      
                }
            }
            //Checks for valid room to run into. If hero is in bottom left corner. 
            //Randomly chooses a direction and goes to that room.
            else if( h.getLocation().x == 4 && h.getLocation().y == 0 ) {
                direction = randDir.nextInt( 2 ) + 1;

                switch( direction ){
                    case 1:
                        h.goNorth();
                        break;
                    case 2:
                        h.goEast();
                        break;
                    default:
                        break;      
                }
            }
            //Checks for valid room to run into. If hero is in bottom right corner. 
            //Randomly chooses a direction and goes to that room.
            else if( h.getLocation().x == 4 && h.getLocation().y == 4 ) {
                direction = randDir.nextInt( 2 ) + 1;

                switch( direction ){
                    case 1:
                        h.goNorth();
                        break;
                    case 2:
                        h.goWest();
                        break;
                    default:
                        break;      
                }
            }
            //Checks for valid room to run into. If hero on the left side of the map. 
            //Randomly chooses a direction and goes to that room.
            else if( h.getLocation().x == 0 ) {
                direction = randDir.nextInt( 3 ) + 1;

                switch( direction ){
                    case 1:
                        h.goSouth();
                        break;
                    case 2:
                        h.goEast();
                        break;
                    case 3:
                        h.goWest();
                        break;
                    default:
                        break;      
                }
            }
            //Checks for valid room to run into. If hero on the right side of the map. 
            //Randomly chooses a direction and goes to that room.
            else if( h.getLocation().x == 4 ) {
                direction = randDir.nextInt( 3 ) + 1;

                switch( direction ){
                    case 1:
                        h.goNorth();
                        break;
                    case 2:
                        h.goEast();
                        break;
                    case 3:
                        h.goWest();
                        break;
                    default:
                        break;      
                }
            }
            //Checks for valid room to run into. If hero on the top side of the map. 
            //Randomly chooses a direction and goes to that room.
            else if( h.getLocation().y == 0 ) {
                direction = randDir.nextInt( 3 ) + 1;

                switch( direction ){
                    case 1:
                        h.goSouth();
                        break;
                    case 2:
                        h.goNorth();
                        break;
                    case 3:
                        h.goEast();
                        break;
                    default:
                        break;      
                }
            }
            //Checks for valid room to run into. If hero on the bottom side of the map. 
            //Randomly chooses a direction and goes to that room.
            else if( h.getLocation().y == 4 ) {
                direction = randDir.nextInt( 3 ) + 1;

                switch( direction ){
                    case 1:
                        h.goSouth();
                        break;
                    case 2:
                        h.goNorth();
                        break;
                    case 3:
                        h.goEast();
                        break;
                    default:
                        break;      
                }
            }
            //Checks for valid room to run into. If hero is anywhere in the middle.
            //Randomly chooses a direction and goes to that room.
            else{
                direction = randDir.nextInt( 4 ) + 1;

                switch( direction ){
                    case 1:
                        h.goSouth();
                        break;
                    case 2:
                        h.goNorth();
                        break;
                    case 3:
                        h.goEast();
                        break;
                    case 4:
                        h.goWest();
                        break;
                    default:
                        break;      
                }
            }
        }
        return isRoomCleared;
    }
    
    /**
     * The Fight method. This will determine if the hero wants to fight or run away.
     * If the hero wants to fight it will prompt and call all the method to make that happen.
     * The enemy will also fight back.
     * 
     * @param h     passes in the enemy object
     * @param e     passes in the hero object
     * @return      returns if true of the hero fights and kills, 
     */
    static boolean fight( Hero h, Enemy e ){
        int move;                       //Saves the move from the user
        int fight;                      //fight is the input from the user
        boolean wannaFight = false;     //if the player wants to fight or not
        boolean won = false;            //if the play won the fight
        
        //Prompts the user to fight or run away
        System.out.printf( "1. Fight\n" +
                           "2. Run Away\n" );
        fight = CheckInput.getIntRange( 1, 2 );
        
        //Checks to see if what the user chose
        if( fight == 1 ){
            wannaFight = true;
        }
        else if( fight == 2 ){
            wannaFight = false;
        }
        
        //while the user wants to fight and he has not beat the monster
        while( wannaFight && !won ){
            //Checks to see if the user has a potion, if they do it will prompt to use it
            if( h.hasPotion() ){
                //prompts the health potion as an option
                System.out.printf( "1. Physical Attack\n" + 
                                   "2. Magical Attack\n" +
                                   "3. Use Health Potion\n" );
                move = CheckInput.getIntRange( 1, 3 );
                
                //if the user wants to use the potion it will heal for 25 hp or 
                //fill up to max if less than 25 hp
                if( move == 3 ){
                    int healthCount = 0;    //used to heap heal the right amount
                    
                    //Heals the user 1 at a time until condition is met
                    while( ( h.getHp() < h.getMaxHp() ) && healthCount < 25 ){
                        h.heal( 1 );
                        healthCount++;
                    }
                    
                    //outputs that it was used and removes it from inventory
                    System.out.println( "You used a Health Potion!" );
                    h.removeItem( "Health Potion" );
                    continue;   //breaks out of loop and checks conditon
                }
            }
            else{
               System.out.printf( "1. Physical Attack\n" + 
                                  "2. Magical Attack\n" );
                move = CheckInput.getIntRange( 1, 2 ); 
            }
            //Checks to see if it was a physical attack
            if( move == 1 ){
                //calls the attack method
                h.attack( e );

                //if the enemy is still alive after the first hit, the enemy will hit back
                if( e.getHp() > 0 ){
                    //enemy hits back
                    e.attack( h );

                    //if the hero dies
                    if( h.getHp() <= 0 ){
                        System.out.printf( "The hero has DIED!!\n" + "Game Over\n ");
                        System.exit( 0 );
                    }
                    else{
                        System.out.println( h.getName() + " terrifyingly exclaims \"" + h.getQuip() +
                                            "\"!" );
                        System.out.println( e.getName() + " frightfully shrieks \"" + e.getQuip() +
                                            "\"!" );
                        e.display();
                    }
                }
                //when ther hero kills the monster
                else{
                    System.out.println( "You defeated the " + e.getName() + "!" );  
                    
                    //if the inventory is filled, it will not add to the inventory
                    if( h.getNumItems() < 5 ){
                        System.out.println( "You received a " + e.getItem().getName() + " from its corpse." );                     
                        h.pickUpItem( e.getItem() );
                    }
                    else{
                        System.out.println( "You can not pick up any more items!" );
                    }
                    
                    //will reload the enemy with it orginal health so that it can be recalled
                    while( e.getMaxHp() > e.getHp() ){
                        e.heal( 1 );
                    }
                    //the user won the fight
                    won = true;
                    continue;
                }
            } 
            //if the user chooses th magical attacks
            else if( move == 2 ){
                //prompts the user of the magical spells
                System.out.println( Magical.MAGIC_MENU );
                move = CheckInput.getIntRange( 1, 3 );
                
                int hit = 0;        //saves the hit from the spell

                System.out.print( h.getName() + " hits " + e.getName() + " with " );
                //Determines which spell to use
                switch( move ){ 
                    case 1:
                        //Saves the hit and then outputs to the console and then applies the damage to the enemy
                        hit = h.magicMissle();
                        System.out.println( "Magic Missle for " + hit + " damage." );
                        e.takeDamage( hit );
                        break;
                    case 2:
                        //Saves the hit and then outputs to the console and then applies the damage to the enemy
                        hit = h.fireball();
                        System.out.println( "Fireball for " + hit + " damage." );
                        e.takeDamage( hit );
                        break;
                    case 3:
                        //Saves the hit and then outputs to the console and then applies the damage to the enemy
                        hit = h.thunderclap();
                        System.out.println( "Thunderclap for " + hit + " damage." );
                        e.takeDamage( hit );
                        break;
                    default:
                        break;
                }
                //if the enemy is still alive, they will attack back and the hit will come of the heros hp
                if( e.getHp() > 0 ){
                    //hits the hero
                    e.attack( h );
                    
                    //if the hero dies
                    if( h.getHp() <= 0 ){
                        System.out.printf( "The hero has DIED!!\n" + "Game Over\n" );
                        System.exit( 0 );
                    }
                    else{
                        //outputs battale cries
                        System.out.println( h.getName() + " terrifyingly exclaims \"" + h.getQuip() +
                                            "\"!" );
                        System.out.println( e.getName() + " frightfully shrieks \"" + e.getQuip() +
                                            "\"!" );
                        e.display();    
                    }
                }
                //when the enemy is defeated
                else{
                    System.out.println( "You defeated the " + e.getName() + "!" );
                    
                    //checks to see if the inventory is full and if not then it adds the enemys item to the hero
                    if( h.getNumItems() < 5 ){
                        h.pickUpItem( e.getItem() );
                        
                        System.out.println( "You received a " + e.getItem().getName() + " from its corpse." );
                    }
                    else{
                        System.out.println( "You can not pick up any more items!" );
                    }
                    
                    //heals the enemy back to normal so it can be used again
                    while( e.getMaxHp() > e.getHp() ){
                        e.heal( 1 );
                    }
                    //hero won the fight
                    won = true;
                    continue;
                }
            } 
            //prompts the user to fight or run away
            System.out.printf( "1. Fight\n" +
                               "2. Run Away\n" );
            fight = CheckInput.getIntRange(1, 2); 
            
            //checks to see what the user wants to do
            if( fight == 1 ){
                wannaFight = true;
            }
            else if( fight == 2 ){
                wannaFight = false;
            }
        }
        return wannaFight;
    }
    
    /**
     * The Store method. Will prompt the user so they can buy a potion, 
     * or sell items out of their inventory.
     * 
     * @param h     passes in the hero object
     * @param ig    passes in the item generator
     */
    static void store( Hero h, ItemGenerator ig ){
        int move;       //used to hold the move
        int select;     //used to hold user input
        
        //prompts the user for input
        System.out.printf( "Hello, " + h.getName() + 
                           "\n1. Buy Potions\n" +
                           "2. Sell Items\n"+ 
                           "3. Exit\n" );
        move = CheckInput.getIntRange( 1, 3 );
        
        //checks to see if the user wants to exit the store
        while( move != 3 ){
            //determines what the user wants to do
            switch( move ){
                //if the user wants to buy a potion
                case 1:
                    //checks if inventory is full
                    if( h.getNumItems() < 5 ){
                        //checks to see if they have enough gold
                        if( h.getGold() >= ig.getPotion().getValue() ){
                            //gets potion and removes gold
                            h.pickUpItem( ig.getPotion() );
                            System.out.println( "Here's your potion, Link" );
                            h.spendGold( ig.getPotion().getValue() );
                        }
                        else{
                            System.out.println( "You do not have enough gold to buy a potion!" );
                        }
                    }
                    else{
                        System.out.println( "You do not have any inventory space!" );
                    }
                    break;
                    //wants to sell items
                case 2:
                    //checks to makes sure inventory is not empty
                    if( h.getNumItems() > 0 ){
                        //prompts the user to choose the item
                        System.out.println( "Choose an item to sell:" );
                        h.displayItems(); 
                        System.out.println( "0. Leave" );
                        select = CheckInput.getIntRange( 0, h.getNumItems() );
                        
                        //if the user wants to leave the sell items
                        if( select == 0 ){
                            break;
                        }
                        //else it removes the item and adds gold and removes armor points
                        else{
                            Item tempItem = h.removeItem( select - 1 );
                            h.collectGold( tempItem.getValue() );
                            h.decreaseMaxHP( tempItem.getValue() );
                        }
                    }
                    else{
                        System.out.println( "You do not have any items to sell!" );
                    }
                    break;
                    //if the user wants to exit
                case 3:
                    continue;
                default:
                    break;
            } 
            System.out.printf( "Hello, " + h.getName() + 
                               "\n1. Buy Potions\n" +
                               "2. Sell Items\n"+ 
                               "3. Exit\n" );
            move = CheckInput.getIntRange( 1, 3 );
        }
    }
    
    /**
     * the Item Room. Picks up an item in a room.
     * 
     * @param h     passes in the hero object
     * @param m     passes in the map object
     * @param ig    passes in the item generator
     * 
     */
    static void itemRoom( Hero h, Map m, ItemGenerator ig ){
        Item newItem = ig.generateItem();   //creats new item
       
        //prints the item the user got and picks up the item
        System.out.println( "You have found a " + newItem.getName() );
        h.pickUpItem( newItem );
    }
    
    /**
     * Main, runs a console program.
     * @param args  passes in the args for main
     */
    public static void main( String[] args ){
        String name;            //used to save the name of the hero
        String battlecry;       //used to save the battle cry of the hero
        int move = 0;           //user input
        char roomType = 0;      //the room type in the map
        int mapCount = 1;       //what map the hero is on
        
        //prompts for the user to enter the name and battlecry and reads in
        System.out.print( "What is your name, traveler? " );
        name = CheckInput.getString();
        System.out.print( "What is your battlecry, " + name + "? " );
        battlecry = CheckInput.getString();
        
        Map maps = new Map();         //creats a new map
        maps.loadMap( mapCount );     //loads the first map
        
        Hero player = new Hero( name, battlecry, maps );      //Creates a new hero
        ItemGenerator ig = new ItemGenerator();             //creates a new item generator
        EnemyGenerator eg = new EnemyGenerator( ig );         //creates a new enemy generator
        
        //while the user doesnt want to quit the program
        while( move != 5 ){
            //display the heros details and display the current hidden map
            player.display(); 
            maps.displayMap( player.getLocation() );
            
            //prompts the user to go in a driection
            System.out.printf( "1. Go North\n" +
                               "2. Go South\n" +
                               "3. Go East\n" +
                               "4. Go West\n" + 
                               "5. Quit\n" );
            move = CheckInput.getIntRange( 1, 5 );
            
            //determines what direction and saves the char value in the room to the varaible
            switch( move ){
                case 1: 
                    roomType = player.goNorth();
                    break;
                case 2:
                    roomType = player.goSouth();
                    break;
                case 3:
                    roomType = player.goEast();
                    break;
                case 4:
                    roomType = player.goWest();
                    break;
                case 5:
                    System.out.println( "Game Over" );
                    System.exit( 0 );
                default:
                    break;
            }
            //determines what to do with the char for the room
            switch( roomType ){
                //nothing was in the room, the char will be removed and 
                //replaced with an n and the map point will be revealed
                case 'n':
                    System.out.println( "There was nothing here." );
                    maps.removeCharAtLoc( player.getLocation() );
                    maps.reveal( player.getLocation() );
                    break;
                //a monster is in the room,  the char will be removed and 
                //replaced with an n if the monster is dead, if not it will remain marked as a monster room 
                //and the map point will be revealed
                case 'm':
                    boolean killed;
                    killed = monsterRoom( player, maps, eg );
                    if( killed ){
                        maps.removeCharAtLoc( player.getLocation() );
                        maps.reveal( player.getLocation() );
                    }
                    else{
                        maps.reveal( player.getLocation() );
                    }
                    break;
                //the item room where an item will be picked up if space in inventory 
                //if no space then the item will stay there the char will be removed and 
                //replaced with an n and the map point will be revealed
                case 'i':
                    if( player.getNumItems() < 5 ){
                        itemRoom( player, maps, ig );
                        maps.removeCharAtLoc( player.getLocation() );
                        maps.reveal( player.getLocation() );
                    }
                    else{
                        System.out.println( "Your inventory is full! The item will be left here." );
                        maps.reveal( player.getLocation() );
                    }
                    break;
                //the store, the char will be removed and 
                //replaced with an n and the map point will be revealed
                case 's':
                    store( player, ig );
                    break;
                //the finish room will load the new map, the char will be removed and 
                //replaced with an n and the map point will be revealed
                case 'f':
                    ArrayList<Item> tempInv = new ArrayList<>();    //creats a temp arraylist
                    int currentHP = player.getHp();                 //record the heros hp
                    int currentGold = player.getGold();             //records the plays gold
                    
                    mapCount++;     //incremenets the map counter
                    
                    //saves the heros inventory into a temp array list
                    while( player.getNumItems() != 0 ){
                        tempInv.add( player.removeItem( 0 ) );
                    }
                    
                    //determines what map to run using mod
                    switch ( mapCount % 3 ) {
                        case 0:
                            maps.loadMap( 3 );
                            break;
                        case 1:
                            maps.loadMap( 1 );
                            break;
                        case 2:
                            maps.loadMap( 2 );
                            break;
                        default:
                            break;
                    }
                    
                    //creates a new hero
                    player = new Hero( name, battlecry, maps );
                    
                    //loads the temp array into the new players inventory
                    while( !tempInv.isEmpty() ){
                        player.pickUpItem( tempInv.remove(0) );
                    }                
                    
                    //sets the hp and gold back to before the lvl up
                    player.heal( currentHP - 15 );
                    player.collectGold( currentGold - 10 );
                    
                    //increases the level and max hp based on what map count it is on
                    while( player.getLevel() < mapCount ){
                        player.increaseLevel();
                        player.increaseMaxHP( 10 );
                    }
                    break;
                default:
                    break;
            }
        }
    }
}