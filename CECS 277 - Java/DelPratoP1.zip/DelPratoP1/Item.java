/** 
 * Holds all the attributes of an item.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class Item {
    private String name;    //holds the value for the name of the item
    private int value;      //holds the values of the item
    
    /**
     * Class Item default constructor. It will set the class data types to the default terms
     * @param n     passed in name of the item
     * @param v     passed in value of the item
     */
    public Item( String n, int v ){
        this.name = n;
        this.value = v;
    }
    
    /**
     * Return the name of the item.
     * @return return the name of the item
     */
    public String getName(){
        return this.name;
    }
    
    /**
     * Returns the value of the item.
     * @return return the value of the item
     */
    public int getValue(){
        return this.value;
    }
}