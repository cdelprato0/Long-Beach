/** 
 * 
 *Interface willed with magical spell that are implemented in other classes.
 *
 * @author Chaz Del Prato - CECS 227
 */
public interface Magical{
    //A static string that holds the text for the output for when the user gets to choose a spell
    public static final String MAGIC_MENU = "1. Magic Missile\n2. Fireball\n3. Thunderclap";
    
    /**
     * Cast a magic missile. Implemented elsewhere.
     * @return returns an integer
     */ 
    public int magicMissle();
    
    /**
     * Cast a Fire ball spell. Implemented elsewhere.
     * @return returns an integer
     */ 
    public int fireball();
    
    /**
     * Cast a thunderclap spell. Implemented elsewhere
     * @return returns an integer
     */ 
    public int thunderclap();
}