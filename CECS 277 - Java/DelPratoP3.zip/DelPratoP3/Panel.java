import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.*;

/** 
 *  Creates the panel for the window. Able to add all the swing components to the 
 * panel have have them be displayed. Implements Action listener so it can determine
 * if a button was pressed. Extends JPanel
 * 
 * @author Chaz Del Prato - CECS 227
 */
public class Panel extends JPanel implements ActionListener {
    /** Variables for all the JButtons. */
    private JButton btnSubmit, btnComplete, btnPostpone, btnAddTask, btnQuit;
    
    /** Variables for all the JLabels. */
    private JLabel lblTasks, lblCurrent, lblCompleteBy, lblAdd, lblDate, lblTime, lblTaskName, lblPostpone, lblError;
    
    /** Variables for all the JTextFields. **/
    private JTextField tfCurrent, tfCompleteBy, tfTaskName, tfMonth, tfDay, tfYear, tfHour, tfMinute;
    
    /** Variable for the list model, will help with keeping list up to date. **/
    private DefaultListModel model;
    
    /** Variable for the JList. **/
    private JList<Task> lstList;
    
    /** Variable for a heap of Task objects. **/
    private Heap<Task> heap;
    
    /** Used to see if the postpone flagged is on. **/
    private boolean isPostpone = false;
    
    /** 
    *  Constructor for the panel. All the placements of the GUI objects will be set here.
    * 
    */
    public Panel(){
        //Create a new heap
        heap = new Heap<Task>();
        //Set the layout to null so the panel can be customized
        setLayout( null );
        //read in from the text file
        readFile();
        //create a new list model
        model = new DefaultListModel();
        
        //*******
        //BUTTONS
        //*******
        btnSubmit = new JButton( "Submit" );        //Creates the new button
        btnSubmit.addActionListener( this );        //Calls the Action Listener so something can happen when the button is clicked
        add( btnSubmit );                           //Adds the button to the panel
        btnSubmit.setBounds( 685, 585, 100, 50 );   //Sets the location of the button on the window
        btnSubmit.setVisible( false );              //Hides the button until it is ready to be used
        
        //Creates new button, calls ActionListener, adds button to the panel, 
        //and sets the postion on the panel
        btnComplete = new JButton( "Completed!" );
        btnComplete.addActionListener( this );
        add( btnComplete );
        btnComplete.setBounds( 525, 200, 100, 50 );
        
        //Creates new button, calls ActionListener, adds button to the panel, 
        //and sets the postion on the panel
        btnPostpone = new JButton( "Postpone" );
        btnPostpone.addActionListener( this );
        add( btnPostpone );
        btnPostpone.setBounds( 675, 200, 100, 50 );
        btnPostpone.setVisible( false );            //Sets invisiable until needed
        btnPostpone.setEnabled( false );            //ensures it can not be clicked until needed
        
        //Creates new button, calls ActionListener, adds button to the panel, 
        //and sets the postion on the panel
        btnAddTask = new JButton( "Add Task" );
        btnAddTask.addActionListener( this );
        add( btnAddTask );
        btnAddTask.setBounds( 675, 200, 100, 50 );
        
        //Creates new button, calls ActionListener, adds button to the panel, 
        //and sets the postion on the panel
        btnQuit = new JButton( "Quit" );
        btnQuit.addActionListener( this );
        add( btnQuit );
        btnQuit.setBounds( 450, 850, 100, 50 );
        
        
        //******
        //LABELS
        //******
        lblTasks = new JLabel( "Tasks:" );      //Creates the new label and sets the text
        add( lblTasks );                        //adds the label to the panel
        lblTasks.setBounds( 50, 25, 50, 50 );   //Sets the location of the label on the panel
        
        //Creates new label, adds the label to the panel, and sets the location on the panel
        lblCurrent = new JLabel( "Current Task:" );
        add( lblCurrent );
        lblCurrent.setBounds( 500, 25, 100, 50 );
        
        //Creates new label, adds the label to the panel, and sets the location on the panel
        lblCompleteBy = new JLabel( "Complete By:" );
        add( lblCompleteBy );
        lblCompleteBy.setBounds( 500, 90, 100, 50 );
        
        //Creates new label, adds the label to the panel, and sets the location on the panel
        lblAdd = new JLabel( "Add Task:" );
        add( lblAdd );
        lblAdd.setBounds( 500, 400, 100, 50 );
        lblAdd.setVisible( false );             //Hides until the label is needed
        
        //Creates new label, adds the label to the panel, and sets the location on the panel
        //and hides the label until needed
        lblPostpone = new JLabel( "Postpone Task:" );
        add( lblPostpone );
        lblPostpone.setBounds( 500, 400, 100, 50 );
        lblPostpone.setVisible( false );
        
        //Creates new label, adds the label to the panel, and sets the location on the panel
        //and hides the label until needed
        lblDate = new JLabel( "Date:" );
        add( lblDate );
        lblDate.setBounds( 510, 440, 100, 50 );
        lblDate.setVisible( false );
        
        //Creates new label, adds the label to the panel, and sets the location on the panel
        //and hides the label until needed
        lblTime = new JLabel( "Time:" );
        add( lblTime );
        lblTime.setBounds( 510, 480, 100, 50 );
        lblTime.setVisible( false );
        
        //Creates new label, adds the label to the panel, and sets the location on the panel
        //and hides the label until needed
        lblTaskName = new JLabel( "Task:" );
        add( lblTaskName );
        lblTaskName.setBounds( 510, 520, 100, 50 );
        lblTaskName.setVisible( false );
        
        //Creates new label, adds the label to the panel, and sets the location on the panel
        //and hides the label until needed
        lblError = new JLabel( "Please correctly fill out the Date/Time boxes! (Format: MM DD YYYY / HH MM)" );
        add( lblError );
        lblError.setBounds( 500, 620, 450, 50 );
        lblError.setForeground( Color.red );            //sets the text to red
        lblError.setVisible( false );
        
        
        //**********
        //TextFields
        //**********
        tfCurrent = new JTextField( "", 20 );       //Creates a new Text Field and stores nothing inside of it
        add( tfCurrent );                           //Adds the text field to the panel
        tfCurrent.setBounds( 500, 60, 300, 30 );    //Sets the location on the panel of the text field
        tfCurrent.setEditable( false );             //Sets the text field so that it can not be edited
        
        //creates a new text field, adds it to the panel, sets the location, 
        //and makes it so it can not be edited
        tfCompleteBy = new JTextField( "", 20 );
        add( tfCompleteBy );
        tfCompleteBy.setBounds( 500, 130, 300, 30 );
        tfCompleteBy.setEditable( false );
        
        //creates a new text field, adds it to the panel, sets the location, 
        //and makes it invisible until needed
        tfTaskName = new JTextField( "", 20 );
        add( tfTaskName );
        tfTaskName.setBounds( 560, 530, 225, 30 );
        tfTaskName.setVisible( false );
        
        //creates a new text field, adds it to the panel, sets the location, 
        //and makes it invisible until needed
        tfMonth = new JTextField( "", 2 );
        add( tfMonth );
        tfMonth.setBounds( 560, 450, 40, 30 );
        tfMonth.setVisible( false );
        
        //creates a new text field, adds it to the panel, sets the location, 
        //and makes it invisible until needed
        tfDay = new JTextField( "", 2 );
        add( tfDay );
        tfDay.setBounds( 605, 450, 40, 30 );
        tfDay.setVisible( false );
        
        //creates a new text field, adds it to the panel, sets the location, 
        //and makes it invisible until needed
        tfYear = new JTextField( "", 4 );
        add( tfYear );
        tfYear.setBounds( 650, 450, 55, 30 );
        tfYear.setVisible( false );
        
        //creates a new text field, adds it to the panel, sets the location, 
        //and makes it invisible until needed
        tfHour = new JTextField( "", 2 );
        add( tfHour );
        tfHour.setBounds( 560, 490, 40, 30 );
        tfHour.setVisible( false );
        
        //creates a new text field, adds it to the panel, sets the location, 
        //and makes it invisible until needed
        tfMinute = new JTextField( "", 2 );
        add( tfMinute );
        tfMinute.setBounds( 605, 490, 40, 30 );
        tfMinute.setVisible( false );
        
        //Updates the Jlist to have all the current values in it
        updateList();
        
        add( lstList );                         //Adds the JList to the panel
        lstList.setBounds( 50, 60, 350, 700 );  //Sets the location and size of the JList
        lstList.setVisible( true );             //Makes sure it is displayed
        
        //Sets the current and completed by text fields so we know which element is being looked at
        tfCurrent.setText( heap.getCurrent().getTaskName() );
        tfCompleteBy.setText( heap.getCurrent().getDueDate().substring( 1 ) );  //ignores the , in the front of the due date
    }

    /** 
    *  Overridden action method that is used to get the action when a button is clicked.
    * Only works for the buttons. Click and release of the button.
    * 
     * @param e  The action event passed in, button being pressed
    */
    @Override
    public void actionPerformed( ActionEvent e ) {
        //When the completed button is pressed.        
        if( e.getSource() == btnComplete ){
            //Checks if the list is empty then it will removed the root from the heap and update the list.
            //If it is empty then it will display a red label stating the list is empty.
            if( !heap.isEmpty() ){
                heap.removeItem();
                
                updateList();
                
                //If the list is not empty it will set the current and completed text fields with
                //the next root in the heap. If not it will set the text fields to nothing.
                if( !heap.isEmpty() ){
                    tfCurrent.setText( heap.getCurrent().getTaskName() );
                    tfCompleteBy.setText( heap.getCurrent().getDueDate().substring( 1 ) );
                }
                else{
                    tfCurrent.setText( "" );
                    tfCompleteBy.setText( "" );
                }
            }
            else{
                lblError.setText( "The Task List is empty!" );
                lblError.setVisible( true );
            }
        }
        
        //If the Add Task button is pressed/
        if( e.getSource() == btnAddTask ){
            btnAddTask.setVisible( false );     //Sets the add task button to invisible
            btnAddTask.setEnabled( false );     //Sets the add task button to disabled
            btnPostpone.setVisible( true );     //sets the postpone task button to visible
            btnPostpone.setEnabled( true );     //sets the postpone task button to enabled
            btnSubmit.setVisible( true );       //sets the submit button to visible
            
            //Sets the Add, Taskname, Date, and Time labels to visible.
            //Sets the postpone label to invisible
            lblAdd.setVisible( true );
            lblPostpone.setVisible( false );
            lblTaskName.setVisible( true );
            lblDate.setVisible( true );
            lblTime.setVisible( true );
            
            //Sets the Month, Day, year, hour, minute and new taskName to visible.
            tfMonth.setVisible( true );
            tfDay.setVisible( true );
            tfYear.setVisible( true );
            tfHour.setVisible( true );
            tfMinute.setVisible( true );
            tfTaskName.setVisible( true );
            
            //flag for when postpone is active
            isPostpone = false;
        }
        
        //If the postpone button is pressed.
        if( e.getSource() == btnPostpone ){
            //Sets the Add Task button to visible and the postpone button to invisible
            btnAddTask.setVisible( true );
            btnAddTask.setEnabled( true );
            btnPostpone.setVisible( false );
            btnPostpone.setEnabled( false );
            
            //Sets the postpone label to visible.
            //Sets the add and task name labels to visible
            lblAdd.setVisible( false );
            lblPostpone.setVisible( true );
            lblTaskName.setVisible( false );
            
            //sets the taskname text field to invisible
            tfTaskName.setVisible( false );
            
            //flag when postpone is pressed
            isPostpone = true;
        }
        
        //When the submit button is pressed
        if( e.getSource() == btnSubmit ){
            //If the postpone button was pressed or not.
            if( isPostpone ){
                //Checks to see if the heap is empty, 
                //checks if any of the boxes is empty, 
                //checks to see that the correct amount of number for month,day,year..ect are corrrect, 
                //and check to see if the date and time are valid values
                if( !heap.isEmpty() && 
                    !tfMonth.getText().equals( "" ) && !tfDay.getText().equals( "" ) && !tfYear.getText().equals( "" ) && !tfHour.getText().equals( "" ) && !tfMinute.getText().equals( "" ) &&
                    tfMonth.getText().matches( "\\d{2}" ) && tfDay.getText().matches( "\\d{2}" ) && tfYear.getText().matches( "\\d{4}" ) && tfHour.getText().matches( "\\d{2}" ) && tfMinute.getText().matches( "\\d{2}" ) && 
                    Integer.parseInt( tfMonth.getText() ) <= 12 && Integer.parseInt( tfDay.getText() ) <= 31 && Integer.parseInt( tfHour.getText() ) <= 23 && Integer.parseInt( tfMinute.getText() ) <= 59 ){
                    
                    //Removes the root from the heap
                    heap.removeItem();
                    
                    //creates a new task with the same task name
                    Task newTask = new Task( tfCurrent.getText(), tfMonth.getText(), tfDay.getText(), tfYear.getText(), tfHour.getText(), tfMinute.getText() );
                    
                    //Adds the new task back into the heap
                    heap.addItem( newTask );
                    
                    //updates the JList
                    updateList();
                    
                    //Sets the current and completed text fields to the root element
                    tfCurrent.setText( heap.getCurrent().getTaskName() );
                    tfCompleteBy.setText( heap.getCurrent().getDueDate().substring( 1 ) );

                    //Resets all the text fields to nothing after something has been postponed
                    tfTaskName.setText( "" );
                    tfMonth.setText( "" );
                    tfDay.setText( "" ); 
                    tfYear.setText( "" ); 
                    tfHour.setText( "" );
                    tfMinute.setText( "" );
                    
                    //error not displayed
                    lblError.setVisible( false );
                }
                else{
                    //Displays error label if the user did not enter something correctly
                    lblError.setText( "Please correctly fill out the Date/Time boxes! (Format: MM DD YYYY / HH MM)" );
                    lblError.setVisible( true );
                }
            }
            else{
                //checks if any of the boxes is empty, 
                //checks to see that the correct amount of number for month,day,year..ect are corrrect, 
                //and check to see if the date and time are valid values
                if( !tfMonth.getText().equals( "" ) && !tfDay.getText().equals( "" ) && !tfYear.getText().equals( "" ) && !tfHour.getText().equals( "" ) && !tfMinute.getText().equals( "" ) &&
                    tfMonth.getText().matches( "\\d{2}" ) && tfDay.getText().matches( "\\d{2}" ) && tfYear.getText().matches( "\\d{4}" ) && tfHour.getText().matches( "\\d{2}" ) && tfMinute.getText().matches( "\\d{2}" ) && 
                    Integer.parseInt( tfMonth.getText() ) <= 12 && Integer.parseInt( tfDay.getText() ) <= 31 && Integer.parseInt( tfHour.getText() ) <= 23 && Integer.parseInt( tfMinute.getText() ) <= 59 ){
                    
                    //Creates a new task from the inputted data
                    Task newTask = new Task( tfTaskName.getText(), tfMonth.getText(), tfDay.getText(), tfYear.getText(), tfHour.getText(), tfMinute.getText() );
                    
                    //Adds that task to the heap
                    heap.addItem( newTask );
                    
                    //updates the JList
                    updateList();

                    //Sets the current and completed text fields to the root element
                    tfCurrent.setText( heap.getCurrent().getTaskName() );
                    tfCompleteBy.setText( heap.getCurrent().getDueDate().substring( 1 ) );
                   
                    //Resets all the text fields to nothing after something has been added
                    tfTaskName.setText( "" );
                    tfMonth.setText( "" );
                    tfDay.setText( "" ); 
                    tfYear.setText( "" ); 
                    tfHour.setText( "" );
                    tfMinute.setText( "" );
                    
                    //keeps the error hidden
                    lblError.setVisible( false );
                }
                else{
                    //Displays error label if the user did not enter something correctly
                    lblError.setVisible( true );
                    lblError.setText( "Please correctly fill out the Date/Time boxes! (Format: MM DD YYYY / HH MM)" );
                }
            }                    
        }
        
        //When the Quit button is pressed.
        if( e.getSource() == btnQuit ){
            //saves the contents of the heap to a text file
            saveFile();
            //closes the window and ends the program
            System.exit( 0 );
        }        
    }
    
    /** 
    *  Updates the JList.
    * 
    */
    public void updateList(){
        //Creats a new JList
        lstList = new JList( model ); 
        //Removes all the old elements from the JList
        model.removeAllElements();
     
        //Adds the name of each task to the JList
        for( int i = 0; i < heap.size(); i++ ){
            String name = heap.toFile( i );
            String[] taskName = name.split( "," );  //Splits at the comma so it only display the names
            
            model.add( i, taskName[0] );
        }
    }
    
    /** 
    *  Reads in from a file. Splits the input at the comma, forward slash, whitespace, and :
    * 
    */
    public void readFile(){
        try{
            //Reads from Scanner
            Scanner inFile = new Scanner( new File( "taskList.txt" ) );
            
            String input;       //holds the whole line being read
            String[] split;     //holds the first split
            String[] split2;    //holds the second split
            
            //While the input file has not reached the end
            do{
                //read in the input and split it two times
                input = inFile.nextLine();
                split = input.split( "[,/]" );
                split2 = split[3].split( "[\\s:]" );
                
                //Add a new task with the task name, month, day, year, hour and minute
                Task newTask = new Task( split[0], split[1], split[2], split2[0], split2[1], split2[2] );
                   
                //Add the element to the heap
                heap.addItem( newTask );
            }while( inFile.hasNext() );         
            
            inFile.close();     //closes the input file
        }catch( FileNotFoundException err ){
            //displays an error if the file could not be found
            System.out.println( "File Not Found" );
        }
    }
    
    /** 
    *  Outputs to a txt file.
    * 
    */
    public void saveFile(){
        try{
            //Uses print writer to output to the file provided
            PrintWriter outFile = new PrintWriter( new File( "taskList.txt" ) );
                     
            //Outputs every element of the heap to the file
            for( int i = 0; i < heap.size(); i++ ){
                outFile.println( heap.toFile( i ) );
            }
            
            outFile.close();    //closes the output file
        }catch( FileNotFoundException er ){
            //throws an error if the file can not be found
            System.out.println( "File Failed" );
        }
    }
}
