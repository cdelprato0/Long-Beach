/** 
 * The Task class will hold the attributes of a task.
 * Implements Comparable. Generic type of Task.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class Task implements Comparable<Task>{
    
    /** The string that holds the name of the task. */
    private String taskName;
    /** The string that holds the date of the task. */
    private String dueDate;
    
    /**
     * Constructor that initializes the Task attributes to null.
     */
    public Task(){
        taskName = "";
        dueDate = "";
    }
    
    /**
     * This is the non default constructor that sets the task name and due date.
     * 
     * @param task      the name of the task
     * @param month     the month the task is due
     * @param day       the day the task is due
     * @param year      the year the task is due
     * @param hour      the hour the task is due
     * @param minute    the minute the task is due
     */
    public Task( String task, String month, String day, String year, String hour, String minute ){
        taskName = task;
        dueDate = "," + month + "/" + day + "/" + year + " " + hour + ":" + minute;
    }
    
    /**
     * Returns the task name.
     * 
     * @return returns the task name
     */
    public String getTaskName(){
        return taskName;
    }
    
    /**
     * Returns the due date.
     * 
     * @return returns the due date
     */
    public String getDueDate(){
        return dueDate;
    }
    
    /**
     *  Overridden toString method that will display the task name and due date together.
     * 
     * @return returns the task name and due date together in a string
     */
    @Override
    public String toString(){
        return taskName + dueDate;
    }

    /**
     *  Overridden compareTo() method that will compare the due date of the task 
     * and determine which date is earlier in time.
     * Determines if the due dates are equal then it will check the names of the task.
     * Checks the year of the due date.
     * 
     * @param o     Task that is being compared
     * @return      returns the result of the compare (1,0,-1);
     */
    @Override
    public int compareTo( Task o ) {
       if( dueDate.equals( o.getDueDate() ) ){
           return taskName.compareTo( o.getTaskName() );
       }
       else if( !dueDate.substring( 7, 11 ).equals( o.getDueDate().substring( 7, 11 ) ) ){
           return dueDate.substring( 7, 11 ).compareTo( o.getDueDate().substring( 7, 11 ) );
       }
       return dueDate.compareTo( o.getDueDate() );
    }
}
