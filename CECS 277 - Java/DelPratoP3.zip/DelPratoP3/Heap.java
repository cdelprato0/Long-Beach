import java.util.ArrayList;

/** 
 * Creates a heap using an ArrayList. Will be able to add and remove elements of the heap.
 * The heap is a min heap and will remove from the root. The heap is generic so any data
 * type can be used with it. 
 * Extends Comparable
 *
 * @author Chaz Del Prato - CECS 227
 * 
 * @param <T>   generic type T
 */
public class Heap <T extends Comparable<T>>{
    
    /* The heap is stored into an array list **/
    private ArrayList<T> heap;
    
    /**
     * Constructor that will create a new ArrayList of generic type T.
     * 
     */
    public Heap() {
        heap = new ArrayList<T>();
    }
    
    /**
     * Returns the size of the ArrayList.
     * 
     * @return integer size of ArrayList
     */
    public int size(){
        return heap.size();
    }
    
    /**
     * Checks to see if the ArrayList is empty.
     * 
     * @return  returns true if empty, false if not
     */
    public boolean isEmpty(){
        return heap.isEmpty();
    }
    
    /**
     * Adds an element to the heap. 
     * This is a min heap so it will keep the smallest value at the root.
     * 
     * @param item  The item that is being added to the heap
     */
    public void addItem( T item ){
        //Adds a node to the ArrayList
        heap.add( null );
        //determines how many elements are already in the array
        int index = heap.size() - 1;
        
        //Checks to see if the index is greater than zero and if the parent of the 
        //element is greater than the current element. If the parent is bigger then 
        //the new element will be pushed up.
        while( index > 0 && getItem( getPLoc( index ) ).compareTo( item ) > 0 ){
            //Sets the new element to the new location
            heap.set( index, getItem( getPLoc( index ) ) );
            //Changes the new elements index
            index = getPLoc( index );
        }
        //Sets the item into its spot once there is not more parents greater than it
        heap.set( index, item );
    }
    
    /**
     * Removes the root from the heap.
     * 
     * @return Returns the generic type T
     */
    public T removeItem(){
        //saves the root
        T min = heap.get( 0 );
        //Saves the index
        int index = heap.size() - 1;
        //Saves the last element of the heap
        T last = heap.remove( index );
        
        //Checks if the heap is empty
        if( index > 0 ){
            //Sets the root to the last element in the heap
            heap.set( 0, last );
            //Sets the root
            T root = heap.get( 0 );
            int end = heap.size() - 1;
            index = 0;
            //Check if done
            boolean done = false;
            
            while( !done ){
                //If the left child exists
                if( getLCLoc( index ) <= end ){
                    T child = getItem( getLCLoc( index ) );
                    int childLoc = getLCLoc( index );
                    //If the right child exists
                    if( getRCLoc( index ) <= end ){
                        if( ( getItem( getRCLoc( index ) ) ).compareTo( child ) < 0 ){
                            child = getItem( getRCLoc( index ) );
                            childLoc = getRCLoc( index );
                        }
                    }
                    if( child.compareTo( root ) < 0 ){
                        heap.set( index, child );
                        index = childLoc;
                    } 
                    else{
                        done = true;
                    }
                } 
                else{    //There are not children
                    done = true;
                }
            }
            heap.set( index, root );
        }
        return min;
    }
    
    /**
     * Overridden toString() that outputs the task name and due date.
     * Tree order not sorted order.
     * 
     * @return task and due date
     */
    @Override
    public String toString(){
        //Returns string in tree order not sorted order        
        String s = "";
        
        for( int i = 0; i < heap.size(); i++ ){
            s += heap.get( i ) + "\n";
        }
        return s;
    }
    
    /**
     * Returns the root of the heap.
     * 
     * @return returns the heap root
     */
    public T getCurrent(){
        return heap.get( 0 );
    }
  
    /**
     * Used to output to the file. Calls objects tostring
     * 
     * @param i     index passed in to find the heap element
     * @return      returns the name and due date
     */
    public String toFile( int i ){
        String s = "";
        
        s = heap.get( i ).toString();
        return s;
    }
    
    /**
     * Returns the parents location of the passed in index.
     * 
     * @param i     heap index passed in
     * @return      returns the parent location
     */
    private int getPLoc( int i ){
        return ( i - 1 ) / 2;
    }
    
    /**
     * Returns the left child's location.
     * 
     * @param i     index of the element
     * @return      returns the left child location
     */
    private int getLCLoc( int i ){
        return 2 * i + 1;
    }
    
    /**
     * Returns the right child's location.
     * 
     * @param i     index of the element
     * @return      returns the right child location
     */
    private int getRCLoc( int i ){
        return 2 * i + 2;
    }
    
    /**
     * Returns the given generic type T.
     * 
     * @param i     index of the element in the heap
     * @return      returns the generic type T
     */
    private T getItem( int i ){
        return heap.get( i );
    }
}