import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

/** 
 * Hero will be the player throughout the game. It extends Entity and implements Magical.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class Hero extends Entity implements Magical{
    
    /* Creates a array list of items **/
    private ArrayList<Item> items = new ArrayList<>();  
    /* Creates a variable to the map class **/
    private Map map;                                    
    /* creates a variable to the point class **/
    private Point location;                             
    /* saves the amount of gold **/
    private int gold;                                   
    
    /**
     * Hero default constructor. Calls the supers (Entity) constructor.
     * @param n     passes in the name of the hero
     * @param q     passes in the battle cry of the hero
     * @param m     passes in the map for the hero
     */ 
    public Hero( String n, String q, Map m ){
        //Calls the super constructor
        super( n, q, 1, 15 );
        this.map = m;
        this.gold = 10;
        this.location = map.findStart();    //finds the start loaction of the hero
    }
    
    /**
     * Overridden display method that calls the Entity display. Displays the gold the hero has.
     */ 
    @Override
    public void display(){
        //Calls the super display, then displays the amount of good for the hero 
        //and displays the heros inventory.
        super.display();
        System.out.println( "$: " + this.gold );
        displayItems();
    }
      
    /**
     * Displays the inventory of the hero.
     */ 
    public void displayItems(){
        System.out.println( "Inventory:" );
        
        //Loops through the items in the inventory and prints them out
        for( int i = 0; i < items.size(); i++ ){
            System.out.println( ( i+1 ) + ". " + items.get( i ).getName() );
        }
        
    }
    
    /**
     * Returns the number of items in the inventory. 
     * @return returns the size of the items array list
     */ 
    public int getNumItems(){
        return items.size();
    }
    
    /**
     * Picks up an item dropped from monster or picked up in room. 
     * @param i     passes in the item to be picked up
     * @return      returns if the item was picked up or not
     */ 
    public boolean pickUpItem( Item i ){
        //Checks to see if the item is a bag of gold, if it is then it adds the 
        //gold to the gold count and not to the inventory.
        if( i.getName().equals( "Bag o' Gold" ) ){
           this.gold = this.gold + i.getValue();
        }
        //Checks to see if the item is a health potion and that the inventory is not full
        else if( !i.getName().equals( "Health Potion" ) && ( getNumItems() < 5 ) ){
            items.add( i );
            increaseMaxHP( i.getValue() );
            return true;
        }
        //Picks up the item if the inventory is not full
        else if( getNumItems() < 5 ){
            items.add( i );
            return true;
        }
        return false;
    }
    
    /**
     * Removes an item from the inventory by the name. 
     * @param n     passes in the string of the item to be removed
     * @return      returns the item that was removed.
     */ 
    public Item removeItem( String n ){
        Item temp = null;   //creates an temporay item
        
        //Searches the array list for that item and removes it from the list
        for( int i = 0; i < items.size(); i++ ){
            if( items.get( i ).getName().equals( n ) ){
                temp = items.remove( i );
            }
        }
        return temp;
    }
    
    /**
     * Removes an item from the inventory by index number.
     * @param index     passes in the index of the item to be removed
     * @return          returns the item that was removed
     */ 
    public Item removeItem( int index ){
        return items.remove( index );
    }
    
    /**
     * Checks to see if the hero has a potion in its inventory.
     * @return returns true or false if it has a health potion
     */ 
    public boolean hasPotion(){
        //Searches the array list for a health potion
        for( int i = 0; i < items.size(); i++ ){
            if( items.get( i ).getName().equals( "Health Potion" ) ){
                return true;
            }
        }
        return false;
    }
    
    /**
     * Returns the location of the hero.
     * @return returns the point on the map where the hero is
     */ 
    public Point getLocation(){
        return location;
    }
    
    /**
     * Moves the hero to the North. Checks to see if the player will go out of bounds.
     * @return returns the char value after the hero moved to the new spot
     */ 
    public char goNorth(){
        if( location.x > 0 ){        
            location.translate( -1, 0 );
        }
        return map.getCharAtLoc( location );
    }
    
    /**
     * Moves the hero to the South. Checks to see if the player will go out of bounds.
     * @return returns the char value after the hero moved to the new spot 
     */ 
    public char goSouth(){
        if( location.x < 4 ){        
            location.translate( 1, 0 );
        }        
        return map.getCharAtLoc( location );
    }
      
    /**
     * RMoves the hero to the East. Checks to see if the player will go out of bounds.
     * @return returns the char value after the hero moved to the new spot 
     */ 
    public char goEast(){
        if( location.y < 4 ){        
            location.translate( 0, 1 );
        }
        return map.getCharAtLoc( location );
    }
      
    /**
     * Moves the hero to the West. Checks to see if the player will go out of bounds.
     * @return returns the char value after the hero moved to the new spot
     */ 
    public char goWest(){
        if( location.y > 0 ){
            location.translate( 0, -1 );
        }
        return map.getCharAtLoc( location );
    }
    
    /**
     * Returns the current gold the hero has. 
     * @return return the amount the of gold the hero has
     */ 
    public int getGold(){
        return this.gold;
    }
    
    /**
     * Adds gold to the current amount of gold. 
     * @param g     the amount of gold that is being added
     */ 
    public void collectGold( int g ){
        gold = gold + g;
    }
    
    /**
     * Subtracts the amount of gold the hero is spending.
     * @param g     passes in the amount of gold that will be taken away
     */ 
    public void spendGold( int g ){
        gold = gold - g;
    }

    /**
     * Overridden method from Entity attack. Performs the physical attack on the enemy. 
     */ 
    @Override
    void attack( Entity e ) {
        //Randomly determines a hit for the physical amount by using the heros level
        Random randHeroHit = new Random();
        int heroHit = randHeroHit.nextInt( 8 * getLevel() ) + 1;
        
        System.out.println( getName() + " attacks " + e.getName() + " for " 
                   + heroHit + " damage." );
        
        //removes the hp hit from the enemy
        e.takeDamage( heroHit );
    }

    /**
     * Randomly calculates the hit of the magic missile. Overridden from the Magical interface.
     * @return  returns the hit that was created
     */ 
    @Override
    public int magicMissle() {
        //Randomly creates a hit based on level, cannot be zero and then return the hit
        Random randMageHit = new Random();
        int mageHit = randMageHit.nextInt( 5 * getLevel() ) + 1;
        
        return mageHit;    
    }

    /**
     * Randomly calculates the hit of the fireball spell. Overridden from the Magical interface.
     * @return  returns the hit that was created
     */ 
    @Override
    public int fireball() {
        //Randomly creates a hit based on level, cannot be zero and then return the hit
        Random randMageHit = new Random();
        int mageHit = randMageHit.nextInt( 6 * getLevel() ) + 1;
        
        return mageHit;       
    }

    /**
     * Randomly calculates the hit of the thunderclap spell. Overridden from the Magical interface.
     * @return  returns the hit that was created 
     */ 
    @Override
    public int thunderclap() {
        //Randomly creates a hit based on level, cannot be zero and then return the hit
        Random randMageHit = new Random();
        int mageHit = randMageHit.nextInt( 7 * getLevel() ) + 1;
        
        return mageHit;        
    }
        
}
