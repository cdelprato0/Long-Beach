import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/** 
 *  Creates the panel for the window. Able to add all the swing components to the 
 * panel have have them be displayed. Implements Action listener so it can determine
 * if a button was pressed. Implements KeyListener and MouseListener to communitcate with the user.Extends JPanel
 * 
 * @author Chaz Del Prato - CECS 227
 */
public class Panel extends JPanel implements ActionListener, KeyListener, MouseListener {
    
    /** Variables for all the JButtons. */
    private JButton btnFight, btnRunaway, btnPAtt, btnMAtt,  btnFire, btnMagic, btnThunder;
    /** Variables for all the JLabels. */
    private JLabel lblCharInfo, lblHName, lblHLvl, lblHHp, lblGold, lblInv, lblStartEnemyTrader, lblEnterEncounterTrader, lblHeroName, lblHeroLvl, lblHeroHP, lblHeroGold;
    /** Variable for a 2-d JLabel that will display the map. */
    private JLabel[][] lblMap = new JLabel[5][5];
    /** Variable for 2-d JLabel that will display the map. */
    private JLabel[][] lblInventory = new JLabel[2][3];
    /** Variable that creates a new Map. */
    private Map maps;
    /** Variable that creates a new Point. */
    private Point p = new Point(0,0);
    /** Variable that holds the heros name. */
    private String heroName;
    /** Variable that holds the battlecry. */
    private String heroBattleCry;
    
    /** 
    *  Constructor for the panel. All the placements of the GUI objects will be set here.
    * 
    */
    public Panel(){
        //Displays a pop up window that the user can enter the heros name
        heroName = JOptionPane.showInputDialog( this, "Enter Hero's Name" );
        //Displays a popup window that allows the user to enter the battlecry
        heroBattleCry = JOptionPane.showInputDialog( this, "Enter Hero's BattleCry" );
        
        //Creates a new map instance and loads the map
        maps = Map.getInstance();
        maps.loadMap( 1 );
        
        //Creates a new hero 
        Hero newHero = new Hero( heroName, heroBattleCry, maps );
        
        //Sets the background color ot black and creates the layout design
        setBackground( Color.black );
        setLayout( null );
        
        //******
        //LABELS
        //******
        lblCharInfo = new JLabel( "Character Information" );
        add( lblCharInfo );
        lblCharInfo.setBounds( 775, 50, 150, 60 );
        lblCharInfo.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblHName = new JLabel( "Name: " );
        add( lblHName );
        lblHName.setBounds( 745, 110, 50, 60 );
        lblHName.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblHeroName = new JLabel( heroName );
        add( lblHeroName );
        lblHeroName.setBounds( 785, 110, 50, 60 );
        lblHeroName.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblHLvl = new JLabel( "Level: " );
        add( lblHLvl );
        lblHLvl.setBounds( 745, 140, 50, 60 );
        lblHLvl.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblHeroLvl = new JLabel( Integer.toString( newHero.getLevel() ) );
        add( lblHeroLvl );
        lblHeroLvl.setBounds( 785, 140, 50, 60 );
        lblHeroLvl.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblHHp = new JLabel( "HP: " );
        add( lblHHp );
        lblHHp.setBounds( 745, 170, 50, 60 );
        lblHHp.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblHeroHP = new JLabel( newHero.getHp() + "/" + newHero.getMaxHp() );
        add( lblHeroHP );
        lblHeroHP.setBounds( 785, 170, 50, 60 );
        lblHeroHP.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblGold = new JLabel( "$: " );
        add( lblGold );
        lblGold.setBounds( 745, 200, 50, 60 );
        lblGold.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblHeroGold = new JLabel( Integer.toString( newHero.getGold() ) );
        add( lblHeroGold );
        lblHeroGold.setBounds( 785, 200, 50, 60 );
        lblHeroGold.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblInv = new JLabel( "Inventory: " );
        add( lblInv );
        lblInv.setBounds( 745, 230, 80, 60 );
        lblInv.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblStartEnemyTrader = new JLabel( "Entry" );
        add( lblStartEnemyTrader );
        lblStartEnemyTrader.setBounds( 745, 550, 80, 60 );
        lblStartEnemyTrader.setForeground( Color.WHITE );
        
        //Creates the name of the label, adds it to the panel, 
        //sets its location on the panel, and sets the color to white
        lblEnterEncounterTrader = new JLabel( "You enter the dungeon..." );
        add( lblEnterEncounterTrader );
        lblEnterEncounterTrader.setBounds( 745, 600, 150, 60 );
        lblEnterEncounterTrader.setForeground( Color.WHITE );
        
        //Used to hold the value of the x and y cords on the panel
        int x;
        int y = 100;
        
        //Loads the map into the GUI
        for( int i = 0; i < 5; i++ ){
            x = 100;
            for( int j  = 0; j < 5; j++ ){
                //Sets the location in the map
                p.setLocation( i, j );
                //returns the char stored in the map
                String location = Character.toString( maps.getCharAtLoc( p ) );
                
                //Creates the name of the label, adds it to the panel, 
                //sets its location on the panel, and sets the color to white
                lblMap[i][j] = new JLabel( location );
                add( lblMap[i][j] );
                lblMap[i][j].setBounds( x, y, 25, 25 );
                lblMap[i][j].setForeground( Color.white );
                
                //increments for spacing
                x += 130;
            }
            //increments for spacing
            y += 130;
        }
        
        //sets the value for the inventory location
        y = 320;
        //Loads the inventory
        for( int i = 0; i < 2; i++ ){
            x = 755;
            for( int j  = 0; j < 3; j++ ){
                
                //5 objects in 2 rows and three columns
                if( i == 1  && j == 2 ){
                    
                }else{
                    //Creates the name of the label, adds it to the panel, 
                    //sets its location on the panel, and sets the color to white
                    lblInventory[i][j] = new JLabel( "test" );
                    add( lblInventory[i][j] );
                    lblInventory[i][j].setBounds( x, y, 25, 25 );
                    lblInventory[i][j].setForeground( Color.white );
                    
                    //increments the location
                    x += 65;
                }
            }
            //increments the location
            y += 65;
        }
    }
    
    /** 
    *  The paint component helps by drawing the rectanles on the GUI.
    * 
     * @param g used to draw
    */
    @Override
    protected void paintComponent( Graphics g ) {
        //Calls the super constructor
        super.paintComponent( g );
        
        //sets the color of the rectangle to red
        g.setColor( Color.RED );
        
        g.drawRect( 725, 50, 225, 50 );       //draw for the character box small
        g.drawRect( 725, 100, 225, 400 );     //draw for the character box large
        g.drawRect( 725, 550, 225, 50 );      //draw for the small enemy box
        g.drawRect( 725, 600, 225, 300 );     //draw fro the large enemy box
        
        //Creats all the boxes for the map on the GUI
        int y = 50;
        int x = 0;
        for( int i = 0; i < 5; i++ ){
            x = 50;
            for( int j = 0; j < 5; j++ ){
                g.drawRect( x, y, 130, 130 );
                x += 130;
            }
            y += 130;
        }
        
        //Creates all the box for the inventory on the GUI
        y = 300;
        for( int i = 0; i < 2; ++i ){
            x = 745;            
            for( int j = 0; j < 3; ++j ){
                if( i == 1  && j == 2 ){
                    
                }else{
                    g.drawRect( x, y, 65, 65 );
                    x += 65;
                }
            }
            y += 65;
        }
    }

    /** 
    *  Overridden action method that is used to get the action when a button is clicked.
    * Only works for the buttons. Click and release of the button.
    * 
     * @param e  The action event passed in, button being pressed
    */
    @Override
    public void actionPerformed( ActionEvent e ) {    }

    /** 
    *  Overridden action method that is used to get the action when a key on the keyboard is typed.
     * @param e the key event passed in, the key typed
    */
    @Override
    public void keyTyped( KeyEvent e ) {    }

    /** 
    *  Overridden action method that is used to get the action when a key on the keyboard is pressed.
     * @param e the key event passed in, the key pressed
    */
    @Override
    public void keyPressed( KeyEvent e ) {    }

    /** 
    *  Overridden action method that is used to get the action when a key on the keyboard is released.
     * @param e the key event passed in, the key released
    */
    @Override
    public void keyReleased( KeyEvent e ) {    }

    /** 
    *  Overridden action method that is used to get the action when the mouse is clicked.
     * @param e the mouse event passed in, the mouse clicked
    */
    @Override
    public void mouseClicked( MouseEvent e ) { }
    
    /** 
    *  Overridden action method that is used to get the action when the mouse is pressed.
     * @param e the mouse event passed in, the mouse pressed
    */
    @Override
    public void mousePressed( MouseEvent e ) { }

    /** 
    *  Overridden action method that is used to get the action when the mouse is released.
     * @param e the mouse event passed in, the mouse released
    */
    @Override
    public void mouseReleased( MouseEvent e ) { }
    
    /** 
    *  Overridden action method that is used to get the action when the mouse is entered.
     * @param e the mouse event passed in, the mouse entered
    */
    @Override
    public void mouseEntered( MouseEvent e ) { }

    /** 
    *  Overridden action method that is used to get the action when the mouse is exited.
     * @param e the mouse event passed in, the mouse exited
    */
    @Override
    public void mouseExited( MouseEvent e ) { }
    
}
