/** 
 * Creates an Entity that can be extended into the hero and enemy classes.
 * Abstract class.
 * 
 * @author Chaz Del Prato - CECS 227
 */
public abstract class Entity {
    
    /* Saves the name of the entity **/
    private String name;        
    /* saves the battle cry of the entity **/
    private String quip;        
    /* saves the level of the entity **/
    private int level;          
    /* saves the max hit points of the entity **/
    private int maxHp;          
    /* saves the hp of the entity **/
    private int hp;             
    
    /**
     * Entity default constructor. Saves all the variables passed in into the class variables. 
     * @param n     //Passes in the name of the entity
     * @param q     //passes in the battle cry of the entity
     * @param l     //passes in the level of the entity
     * @param m     //passes in the max hit points of the entity
     */ 
    public Entity( String n, String q, int l, int m ){
        this.name = n;
        this.quip = q;
        this.level = l;
        this.maxHp = m;
        this.hp = m;
    }
    
    /**
     * Abstract attack method. Used in the Hero, Enemy, and Magical Enemy classes.
     */ 
    abstract void attack( Entity e );
    
    /**
     * Returns the name.
     * 
     * @return returns the name of the entity
     */ 
    public String getName(){
        return this.name;
    }
    
    /**
     * Returns the battle cry. 
     * @return return the battle cry for the entity
     */ 
    public String getQuip(){
        return this.quip;
    }
    
    /**
     * Returns the level. 
     * @return return the level for the entity
     */ 
    public int getLevel(){
        return this.level;
    }
    
    /**
     * Returns the hit points. 
     * @return return the hit points for the entity
     */ 
    public int getHp(){
        return this.hp;
    }
    
    /**
     * Returns the max hit points. 
     * @return return the max hit points for the entity
     */ 
    public int getMaxHp(){
        return this.maxHp;
    }
    
    /**
     * Increases the level of the entity. 
     */ 
    public void increaseLevel(){
        level = level + 1;
    }
    
    /**
     * Heals the entity. 
     * @param h passes in the amount to be healed
     */ 
    public void heal( int h ){
        hp = hp + h;
    }
    
    /**
     * Take damage on the entity. 
     * @param h passes in the damage to be taken away from the hp
     */ 
    public void takeDamage( int h ){
        //If the hit is greater than or equal to the hp, hp will be zero, killing the entity
        //else it will subtract the damage.
        if( hp <= h ){
            hp = 0;
        }
        else{
            hp = hp - h;
        }
    }
    
    /**
     * Increases the max hit point.
     * @param h passes in the amount the hit points will increase
     */ 
    public void increaseMaxHP( int h ){
        maxHp = maxHp + h;
    }
    
    /**
     * Decreases the max amount of hit points .
     * @param h passes on the amount to subtract
     */ 
    public void decreaseMaxHP( int h ){
        maxHp = maxHp - h;
    }
    
    /**
     * Displays the name, level, hp and max hp of the entity. 
     */ 
    public void display(){
        
    }
}
