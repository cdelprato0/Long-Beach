/**
 *  Creates a Warrior Decorator. used for physical enemies. extends Decorator.
 * @author Chaz
 */
public class Warrior extends Decorator{
    
    /**
    *  Constructor calls the supers constructor (Decorator). Also adds the Warrior title and increase maxHp by 2.
    * @param n     Warrior's name
    * @param m     Warrior's max hit points
    * @param enemy Enemy Object
    * 
    */ 
    public Warrior( String n, int m, Enemy enemy ) {
        super( ( n + " Warrior" ), ( m + 2 ), enemy );
    }
    
    /**
     *  Overridden attack method from the Entity class. Method will calculate the 
     * random physical hit the enemy will preform
     */ 
    @Override
    void attack( Entity e ){
        super.attack( e );
    }
}
