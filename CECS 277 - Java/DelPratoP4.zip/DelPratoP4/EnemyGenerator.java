import java.util.ArrayList;
import java.util.Random;

/** 
 * Creates an array list of all the enemys the game has to offer.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class EnemyGenerator {
    /* The array list that holds all the monsters **/
    private ArrayList<Enemy> enemyList; //
    
    /* Creates an instance for the ItemGenerator **/
    private ItemGenerator ig = ItemGenerator.getInstance();          
   
    /* Creats an instance variable for the EnemyGenerator, used with Singleton design **/
    private static EnemyGenerator instance = null;
    
    /**
     * Default constructor. Made private to meet singleton design.
     * @param ig Passes in the item generator
     */
    private EnemyGenerator(){
        this.enemyList = new ArrayList<>();     //Initializes the enemy list
    }
    
    /**
     * Used to create an instance of EnemyGenerator. Fits the singleton design.
     * Instead of calling the constructor, call the getInstance method.
     * 
     * @return returns an instance of EnemyGenerator
     */
    public static EnemyGenerator getInstance(){
        if( instance == null ){
            instance = new EnemyGenerator();
        }
        return instance;
    }
    
    /**
     * Randomly generates an enemy from the array list and sets its attributes.
     * @param level     takes in the value of the hero
     * @return          returns the enemy
     */
    public Enemy generateEnemy( int level ){
        //randomly picks an enemy from the list
        Random randEnemy = new Random();
        int index = randEnemy.nextInt( enemyList.size() );
        
        //Creates the new hp based on the level of the hearo
        int newHp = ( enemyList.get( index ).getHp() ) * level;
        
        //Increases the max hp and heals the monster to full health
        enemyList.get( index ).increaseMaxHP( newHp - enemyList.get( index ).getMaxHp() );
        enemyList.get( index ).heal( newHp - enemyList.get( index ).getHp() );
        
        return enemyList.get( index );
    }
}
