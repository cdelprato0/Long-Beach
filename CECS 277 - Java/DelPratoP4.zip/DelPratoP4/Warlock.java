
import java.util.Random;

/**
 *  Creates a Warlock Decorator. Implements Magical interface.
 * used for magical enemies. extends Decorator.
 * @author Chaz
 */
public class Warlock extends Decorator implements Magical{

     /**
    *  Constructor calls the supers constructor (Decorator). Also adds the Warlock title and increase maxHp by 1.
    * @param n     Warlock's name
    * @param m     Warlock's max hit points
    * @param enemy Enemy Object
    * 
    */ 
    public Warlock( String n, int m, Enemy enemy ) {
        super( ( n + " Warlock" ),( m + 1 ), enemy );
    }
    
    /**
     * Overridden attack method from Entity. Will preform the magical attacks on the hero.
     * @param e     Passes in the Entity the enemy is fighting
     */ 
    @Override
    public void attack( Entity e ){
        super.attack( e );
        //Randomly chooses one of the three spells
        Random randMageAttack = new Random();
        int mageAttack = randMageAttack.nextInt ( 3 ) + 1;
        int hit;                                            //saved to measure the hit
        
        System.out.print( getName() + " hits " + e.getName() + " with " );
        //Will determine what spell to use
        switch( mageAttack ){
            case 1:
                //Saves the hit and then outputs to the console and then applies the damage to the hero
                hit = magicMissle();    
                System.out.println( "Magic Missle for " + hit + " damage." );
                e.takeDamage( hit );
                break;
            case 2:
                //Saves the hit and then outputs to the console and then applies the damage to the hero
                hit = fireball();
                System.out.println( "Fireball for " + hit + " damage." );
                e.takeDamage( hit );
                break;
            case 3:
                //Saves the hit and then outputs to the console and then applies the damage to the hero
                hit = thunderclap();
                System.out.println( "Thunderclap for " + hit + " damage." );
                e.takeDamage( hit );
                break;
            default:
                break;   
        }
    }
    
    /**
     * Randomly calculates the hit of the magic missile. Overridden from the Magical interface.
     * @return  returns the hit that was created
     */ 
    @Override
    public int magicMissle() {
        //Randomly creates a hit based on level, cannot be zero and then return the hit
        Random randMageHit = new Random();
        int mageHit = randMageHit.nextInt( 5 * getLevel() ) + 1;
        
        return mageHit;
    }

    /**
     * Randomly calculates the hit of the fireball spell. Overridden from the Magical interface.
     * @return  returns the hit that was created
     */ 
    @Override
    public int fireball() {
        //Randomly creates a hit based on level, cannot be zero and then return the hit
        Random randMageHit = new Random();
        int mageHit = randMageHit.nextInt( 6 * getLevel() ) + 1;
        
        return mageHit;   
    }

    /**
     * Randomly calculates the hit of the thunderclap spell. Overridden from the Magical interface.
     * @return  returns the hit that was created
     */ 
    @Override
    public int thunderclap() {
        //Randomly creates a hit based on level, cannot be zero and then return the hit
        Random randMageHit = new Random();
        int mageHit = randMageHit.nextInt( 7 * getLevel() ) + 1;
        
        return mageHit;    
    }
    
}
