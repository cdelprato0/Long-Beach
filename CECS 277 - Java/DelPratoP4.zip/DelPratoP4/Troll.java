/**
 *  Creates a class that is the Troll enemy. Extends from Enemy.
 * @author Chaz
 */
public class Troll extends Enemy{
    
    /**
    *  Constructor calls the supers constructor (enemy).
    * @param n     Troll's name
    * @param q     Troll's war cry
    * @param l     Troll's level
    * @param m     Troll's max hit points
    * @param i     Troll's item
    * 
    */ 
    public Troll( String n, String q, int l, int m, Item i ) {
        super( n, q, l, m, i );
    }
    
    /**
     * Attack method from the Enemy class. 
    */ 
    @Override
    void attack( Entity e ) {
        super.attack( e );
    }    
}
