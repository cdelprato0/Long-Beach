/** 
 * Protoype interface is used to fulfill the Prototype design pattern.
 *
 * @author Chaz Del Prato - CECS 227
 */
public interface Prototype{
    
    /**
     * returns a clone of the prototype class.
     * @return returns a clone of the prototype class
     */ 
    public Prototype clone(); 
}
