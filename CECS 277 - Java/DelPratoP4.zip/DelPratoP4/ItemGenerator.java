import java.io.File;
import java.io.FileNotFoundException;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/** 
 * Reads in from a file to fill an array list of items and generates a new item.
 * Implements the Singleton Design pattern
 *
 * @author Chaz Del Prato - CECS 227
 */
public class ItemGenerator extends Item{
    
    /* used to store the item list **/
    private ArrayList<Item> itemList;   
    /* used to store the new item**/
    private Item newItem;
    /* creates a variable to an instance of ItemGenerator **/
    private static ItemGenerator instance = null;
    
    /**
     * Reads in the item list from a file. Is private to fulfill the singleton design pattern.
     */
    private ItemGenerator(){
        this.itemList = new ArrayList<>();  //Initializes the array list
        String input;                       //Used to save file input
        String[] inputSplit;                //Used to split the input so it can read mutiple values per line
        
        try{
            //Calls a scanner to read the input file
            Scanner readFile = new Scanner( new File( "ItemList.txt" ) );
            
            //Will read the file until it is empty
            do{
                //Reads in a line of the input file and splits at the ',' into a string array
                input = readFile.nextLine();
                inputSplit = input.split( "," );
              
                //creates a new item with the name and the value from the file 
                //and then adds it to the array list. also uses parse int to turn the string into an integer.
                newItem = new Item( inputSplit[0], parseInt( inputSplit[1] ) );
                itemList.add( newItem );
               
            }while( readFile.hasNext() );
            
            //closes the file
            readFile.close();
        }catch( FileNotFoundException fnf ){
            //throws an exception if file not found
            System.out.println( "File was not found" );
        }
    }
    
    /**
     * Used to create an instance of ItemGenerator. Fits the singleton design.
     * Instead of calling the constructor, call the getInstance method.
     * 
     * @return returns an instance of ItemGenerator
     */
    public static ItemGenerator getInstance(){
        if( instance == null ){
            instance = new ItemGenerator();
        }
        return instance;
    }
    
    /**
     * Will randomly generate a new item.
     * @return returns that randomly generated item
     */
    public Item generateItem(){
        //Determines a random number based on the size of the array and return 
        //the item at the random index
        Random randItem = new Random();
        int index = randItem.nextInt( itemList.size() );
        
        newItem.clone();
        
        return itemList.get( index );
    }
    
    /**
     * Returns the health potion.
     * @return returns the health potion to the calling method
     */
    public Item getPotion(){
        //Searches the array list for the potion and returns it. 
        //else or returns the item at the zero index.
        for( int i = 0; i < itemList.size(); i++ ){
            if( itemList.get( i ).getName().equals( "Health Potion" ) ){
                return itemList.get( i );
            }
        }
        return itemList.get( 0 );
    }      
}