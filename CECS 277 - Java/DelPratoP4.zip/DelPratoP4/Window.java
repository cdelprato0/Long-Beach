import javax.swing.JFrame;
/**
 * Creates a window that pops up and loads the Panel class onto it.
 * Extends JFrame.
 * 
 * @author Chaz Del Prato - CECS 277
 */
public class Window extends JFrame {
    
    /**
     * The main of the program.
     * Calls the Window constructor to create a new window.
     * 
     * @param args passed in for console work
     */
    public static void main( String[] args ) {
        Window w = new Window();
    }
    
    /**
     * Constructor to create the window.
     * Sets the dimensions and the title.
     */
    public Window(){
        //Sets the size of the window
        setBounds( 750,250,1000,1000 );
        //Sets the title of the window
        setTitle( "Dungeon Master" );        
        //Sets the close operation to completly close after exiting
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        //Creates a new panel
        setContentPane( new Panel() );
        //Sets the window to visiable.
        setVisible( true );
    }
}