/** 
 * Item class implements the Prototype design pattern. The clone method is overriden.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class Item implements Prototype{
    
    /* holds the value for the name of the item**/
    private String name;    
    /* holds the values of the item**/
    private int value;      
    
    /**
     * Item Constructor. 
     */
    public Item(){
        name = "";
        value = 0;
    }
    
    /**
     * Class Item default constructor. It will set the class data types to the default terms
     * @param n     passed in name of the item
     * @param v     passed in value of the item
     */
    public Item( String n, int v ){
        name = n;
        value = v;
    }
    
    /**
     * Class Item default constructor. Used to complete the prototype design pattern.
     * 
     * @param i Another Item that will be compared with the exsisting Ttem
     */
    public Item( Item i ){
        if( i != null ){
            this.name = i.name;
            this.value = i.value;
        }
    }    
    
    /**
     * Return the name of the item.
     * @return return the name of the item
     */
    public String getName(){
        return this.name;
    }
    
    /**
     * Returns the value of the item.
     * @return return the value of the item
     */
    public int getValue(){
        return this.value;
    }

    /**
     * Returns a clone of Item.
     * @return return a clone of the current Item
     */
    @Override
    public Prototype clone() {
        return new Item( this );
    }
}
