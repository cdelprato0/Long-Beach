import java.util.Random;
/** 
 * Enemy extends Entity, Enemy will hold the attributes of the enemy created.
 *
 * @author Chaz Del Prato - CECS 227
 */
public abstract class Enemy extends Entity {
    
    /* Creates a variable of Item type to hold an item created **/
    private Item item;
    
    /**
     * Class default constructor. Calls Entity's default constructor and sets i = items
     * @param n     Enemy's name
     * @param q     Enemy's war cry
     * @param l     Enemy's level
     * @param m     Enemy's max hit points
     * @param i     Enemy's item
     */ 
    public Enemy( String n, String q, int l, int m, Item i ){
        //Calls the super constructor and passes all the nessaracy parameters
        super( n, q, l, m );
        this.item = i;
    }
    
    /**
     * Returns the Item of the Enemy.
     * @return returns the item created for the enemy
     */ 
    public Item getItem(){
        return this.item;
    }

    /**
     *  Overridden attack method from the Entity class. Method will calculate the 
     * random physical hit the enemy will preform
     */ 
    @Override
    void attack( Entity e ) {
        //Creates a random value from 1 to 7 times the heros level
        Random randEnemyHit = new Random();
        int enemyHit = randEnemyHit.nextInt( 7 * getLevel() ) + 1;
        
        //Calls the entity takeDamage method that will subtract the given hit from the HP
        e.takeDamage( enemyHit );
    }
}
