
import java.util.Random;

/**
 *  A Decorator class that follows the Decorator Design Pattern.
 *  It extends a component called Enemy. Calls the supers constructor.
 * 
 * @author Chaz
 */
public abstract class Decorator extends Enemy{
    
    /* Provideds a reference to the Enemy class **/
    private Enemy en;
    
    /**
     * Class default constructor. Calls Decorators default constructor and sets the enemy object, level and item
     * @param n     Enemy's name
     * @param m     Enemy's max hit points
     * @param enemy Enemy object
     * 
     */ 
    public Decorator( String n, int m, Enemy enemy ) {
        super( n, enemy.getQuip(), enemy.getLevel(), m, enemy.getItem() );
        en = enemy;
    }
    
    /**
     * Attack method from the Enemy class. 
     */ 
    @Override
    void attack( Entity e ) {
        en.attack( e );
    }
    
}
