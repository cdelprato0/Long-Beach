/**
 *  Creates a class that is the Orc enemy. Extends from Enemy.
 * @author Chaz
 */
public class Orc extends Enemy{
    
    /**
    *  Constructor calls the supers constructor (enemy).
    * @param n     Orc's name
    * @param q     Orc's war cry
    * @param l     Orc's level
    * @param m     Orc's max hit points
    * @param i     Orc's item
    * 
    */ 
    public Orc( String n, String q, int l, int m, Item i ) {
        super( n, q, l, m, i );
    }
    
    /**
     * Attack method from the Enemy class. 
    */ 
    @Override
    void attack( Entity e ) {
        super.attack( e );
    }    
}
