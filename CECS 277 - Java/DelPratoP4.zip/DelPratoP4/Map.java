import java.awt.Point;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/** 
 * A character map that will load in a map and keep track of the player and the 
 * rooms the map has to offer.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class Map {
    
    /* Holds the characters read in from the map **/
    private char[][] map = new char[5][5];             
    /* Determines if the character spot has been visited on the map **/
    private boolean[][] revealed = new boolean[5][5];   
    /* creates an instance of the Map**/
    private static Map instance = null;
    
    /**
     * Constructor. Is private to fulfill the singleton design pattern.
     */
    private Map(){
        //This will load 'x's and false's into both the revealed and map char arrays
        for( int i = 0; i < 5; i++ ){
            for( int j = 0; j < 5; j++ ){
                map[i][j] = 'x';
                revealed[i][j] = false;
            }
        }
    }
    
    /**
     * Gets the instance of a new map.
     * @return the instance of the map
     */
    public static Map getInstance(){
        if( instance == null ){
            instance = new Map();
        }
        return instance;
    }
    
    /**
     * Reads from a .txt file and loads the map into a 2-D array.
     * @param mapNum    The number of the map the user wants to load. 
     */    
    public void loadMap( int mapNum ){
        //Basically does what the constructor does but does it each time a new map is loaded
        for( int i = 0; i < 5; i++ ){
            for( int j = 0; j < 5; j++ ){
                map[i][j] = 'x';
                revealed[i][j] = false;
            }
        }
        try{
            //Will determine by the passed in parameter, what map to load
            switch( mapNum ){
                case 1:
                    //Will read in the file for the map using scanner
                    Scanner readIn1 = new Scanner( new File( "map1.txt" ) );
                    
                    //Will run until the file is empty
                    do{
                       //Will load each char into the array
                       for( int i = 0; i < 5; i++ ){
                           for( int j = 0; j < 5; j++ ){
                               //It will read in the next line and read the first value
                               map[i][j] = readIn1.next().charAt(0);
                           }
                       }
                   }while( readIn1.hasNext() );

                   readIn1.close();  //Closes a the input file                     
                   break;
                //Will preform the same thing as the previous case but just a different map will be read in
                case 2:
                        Scanner readIn2 = new Scanner( new File( "map2.txt" ) );
                        do{
                           for( int i = 0; i < 5; i++ ){
                               for( int j = 0; j < 5; j++ ){
                                   map[i][j] = readIn2.next().charAt(0);
                               }
                           }
                       }while( readIn2.hasNext() );

                       readIn2.close();                       
                       break;
                //Will do the same as the previous switch cases
                case 3:
                        Scanner readIn3 = new Scanner( new File( "map3.txt" ) );
                        do{
                           for( int i = 0; i < 5; i++ ){
                               for( int j = 0; j < 5; j++ ){
                                   map[i][j] = readIn3.next().charAt(0);
                               }
                           }
                       }while( readIn3.hasNext() );

                       readIn3.close();                       
                       break;
                default:
                    break;
            }
        }catch( FileNotFoundException fnf ){
            //If there is a problem reading the file it will throw an error
            System.out.println( "File was not found" );    
        }
    }
    
    /**
     * Returns the char at the given point on the map.
     * @param p    The point on the map that will return the contents at of that point
     * @return     returns a char value from the map that is either a 'n', 'm', 's', 'i', or 'f'
     */   
    public char getCharAtLoc( Point p ){
        return map[p.x][p.y];
    }
    
    /**
     * Displays a 5 by 5 map into the console. This method will output the current map so that 
     * the user can track where they have been and what their current location is.
     * @param p    The point on the map.
     */  
    public void displayMap( Point p ){
        //A temp char array will be created so that the data in the map array doesnt get changed
        char[][] tempMap = new char[5][5];
        
        //These two outer for loops will run through the entire 2d map
        for( int i = 0; i < 5; ++i ){
            for( int j = 0; j < 5; ++j ){
                
                //This will check if the point passed in is equal to the current 
                //postion of the hero and place this marker on the map
                if( p.x == i && p.y == j ){
                    tempMap[i][j] = '*';
                }
                //Checks to see if the current point is the start point if not it will load the rest of the map as a x
                else if( map[i][j] != 's' ){
                    tempMap[i][j] = 'x';
                    
                    //If the point is revealed but nothing happened at the point then it will output the 
                    //data stored in the map
                    if( revealed[i][j] && ( map[i][j] == 'i' || map[i][j] == 'm' ) ){
                        tempMap[i][j] = map[i][j];
                    }
                    //Otherwise it will change the point to an n and there will be nothing left
                    else if( revealed[i][j] ){
                        tempMap[i][j] = 'n';
                    }
                }
                else{
                    tempMap[i][j] = map[i][j];
                }
                //helps align the map in the output
                System.out.print( tempMap[i][j] + " " );
            }
            System.out.println( "" );   //adds a newline
        }
    }
    
    /**
     * Determines the start point on the map.
     * @return     returns the point on the map where it had a 's'
     */  
    public Point findStart(){
        Point p = new Point(0,0);   //creates a new point
        
        //iterates through the 2d array
        for( int i = 0; i < 5; ++i ){
            for( int j = 0; j < 5; ++j ){
                //if the point is eqal to s then it found the start point ans saves it
                if( map[i][j] == 's' ){
                    p.x = i;
                    p.y = j;
                    
                    //sets the start point to revealed
                    revealed[i][j] = true;
                    break;
                }
            }
        }
        return p;
    }
    
    /**
     * Sets the revealed 2-d array to true. Used to determine if the user has already visited 
     * that specific location.
     * @param p    The point on the map that the player has entered
     */  
    public void reveal( Point p ){
        revealed[p.x][p.y] = true;
    }
        
    /**
     * Removed the character on the map at the given point. It will replace the char at the given point with a 'n'.
     * @param p    The point on the map that the user has entered
     */  
    public void removeCharAtLoc( Point p ){
        if( map[p.x][p.y] != 's' ){
            map[p.x][p.y] = 'n';
        }
    }
}