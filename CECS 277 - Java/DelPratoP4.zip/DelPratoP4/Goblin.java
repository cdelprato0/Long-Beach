/**
 *  Creates a class that is the Goblin enemy. Extends from Enemy.
 * @author Chaz
 */
public class Goblin extends Enemy{
    
    /**
    *  Constructor calls the supers constructor (enemy).
    * @param n     Goblin's name
    * @param q     Goblin's war cry
    * @param l     Goblin's level
    * @param m     Goblin's max hit points
    * @param i     Goblin's item
    * 
    */ 
    public Goblin( String n, String q, int l, int m, Item i ) {
        super( n, q, l, m, i );
    }
    
    /**
     * Attack method from the Enemy class. 
    */ 
    @Override
    void attack( Entity e ) {
        super.attack( e );
    }   
}
