import java.io.File;

/** 
 * This game will be able to take in user input and a computers prediction to 
 * find if their pokemon can beat each other. The pattern size is 4 characters.
 * The computer will output a random guess until a file is loaded or a pattern is created.
 * The game will be able to read and output to a txt file.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class Main{
    
    /**
     * The main of the program.
     * 
     * @param args passed in for console work
     */
    public static void main( String[] args ){
        Computer computer = new Computer();         //Creates a new computer object
        File newFile = new File( "patterns.txt" );  //creates a new file object and file name
        
        int moveYN;                 //saves the users input for yes/no ?'s
        int move;                   //Saves the choice of pokemon from user
        double playerWins = 0;      //holds the amount of player wins
        double computerWins = 0;    //holds the amount of computer wins
        double round;               //keeps track of the number of rounds
        double aveWon;              //takes the average of the computer wins
        char compPrediction;        //the computers prediction
        String pattern = "";        //the string pattern
        
        //If the file exists in the java directory
        if( newFile.exists() ){
            //Pompts the user if they want to read in from that file
            System.out.println( "Would you like to play the Veteran Computer? (will read in from file) (y/n)" );
            moveYN = CheckInput.getYesNo();
            
            //If the user does then the file will be read in
            if( moveYN == 1 ){
                //reads the file into the computers HashMap
                pattern = computer.readFile( newFile );
                
                System.out.println( "File has been loaded." );
            }
        }
        //Prompts the user to chose a pokemon
        System.out.printf( "Please select your Pokemon: \n"
                         + "1. Fire\n2. Water\n3. Grass\n0. Exit\n" );
        move = CheckInput.getIntRange( 0, 3 );
        
        round = 1;  //sets the begining of the game
        
        //while the user does not want to quit
        while( move !=0 ){
            //sets the computers prediction
            compPrediction = computer.makePrediction( pattern );
            
            //Checks the users input and determines what pokemon they chose. 
            //This will also add the typr of pokemon to the pattern
            switch( move ){
                case 1:
                    System.out.println( "\nYou have chosen a Fire Pokemon!" );
                    pattern += 'F';
                    break;
                case 2:
                    System.out.println( "\nYou have chosen a Water Pokemon!" );
                    pattern += 'W';
                    break;
                case 3:
                    System.out.println( "\nYou have chosen a Grass Pokemon!" );
                    pattern += 'G';
                    break;
                default:
                    //outputs if there is an error
                    System.out.println( "No such input" );
                    break;
            }
            
            //If the pattern is more than 4 characters then it will take off the oldest choice
            if( pattern.length() > 4 ){
                //removes the oldest choice
                pattern = pattern.substring( 1 );
                //stores the pattern 
                computer.storePattern( pattern );
            }
            //if the pattern is four characters then it will store the pattern
            else if( pattern.length() == 4 ){
                computer.storePattern( pattern );
            }
            
            //Checks the computers prediction and outputs what the computer predicited
            switch( compPrediction ){
                case 'F': 
                    System.out.println( "The computer has chosen a Fire Pokemon!" );
                    break;
                case 'W': 
                    System.out.println( "The computer has chosen a Water Pokemon!" );
                    break;
                case 'G': 
                    System.out.println( "The computer has chosen a Grass Pokemon!" );
                    break;
                default:
                    //outputs if there is an error
                    System.out.println( "Error prediction" );
                    break;
            }
            
            //Determines who wins the game. Checks for a tie, a computer win, or a user win.
            //increments the players wins and computer wins.
            if( move == 1 && compPrediction == 'F' || 
                move == 2 && compPrediction == 'W' || 
                move == 3 && compPrediction == 'G' ){
                
                System.out.println( "There is a TIE!" );
            }
            else if( move == 1 && compPrediction == 'G' || 
                     move == 2 && compPrediction == 'F' ||
                     move == 3 && compPrediction == 'W' ){
                
                System.out.println( "You have WON the round!" );
                playerWins++;
            }
            else if( move == 1 && compPrediction == 'W' ||
                     move == 2 && compPrediction == 'G' ||
                     move == 3 && compPrediction == 'F' ){
                
                System.out.println( "The computer has WON the round!" );
                computerWins++;
            }
            
            //Outputs all the end of results after the round
            System.out.println( "\nEnd of Round results: \n"
                              + "---------------------" );
            System.out.println( "You have won " + ( int )playerWins + " times." );
            System.out.println( "The computer has won " + ( int )computerWins + " times." );
            
            //calculates the average wins the computer has
            aveWon = ( computerWins/round ) * 100;
            
            //Outputs the average
            System.out.printf( "The computer has won %.2f", aveWon );
            System.out.println( "% of the rounds!\n" );
            
            //increments the round
            round++;
            
            //Prompts the user again for the input of their pokemon 
            System.out.printf( "Please select your Pokemon: \n"
                             + "1. Fire\n2. Water\n3. Grass\n0. Exit\n" );
            move = CheckInput.getIntRange( 0, 3 );
        }            
        
        //Prompts the user if they want to save the current patterns to a file.
        System.out.println( "Would you like to save the computer's memory? (y/n)" );
        moveYN = CheckInput.getYesNo();
        
        //if the user wants to save the pattern then it will call the computers method
        if( moveYN == 1 ){
            computer.saveMapToFile( newFile );
            System.out.println( "File has been saved." );
        }
        
        System.out.println( "Game Over." );
    }
}
