import java.io.Serializable;
import java.util.Objects;

/** 
 * A pattern is a string of 4 characters. The pattern is used to help the 
 * computer predict the users next move. Implements Objects equals and hashCode methods.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class Pattern{
    
    /** The string the pattern is saved into */
    private String pattern;
    
    /**
     * This is the non default constructor that sets the passed in string to pattern.
     * 
     * @param p passed in string to be saved as pattern
     */
    public Pattern( String p ){
        this.pattern = p;
    }
    
    /**
     * Returns the string to the calling place.
     * 
     * @return the current string pattern
     */
    public String getPattern(){
        return this.pattern;
    }
    
    /**
     * Returns the hash code for the given pattern.
     * Overridden method from Objects class.
     * 
     * @return returns the strings hash code
     */
    @Override
    public int hashCode(){
        return pattern.hashCode();
    }

    /**
     * Checks to see if the object passsed in is equal to the object in this class.
     * Overridden method from Objects class.
     * 
     * @param obj object to be checked
     * @return  true if they are equal, false if they are not
     */
    @Override
    public boolean equals( Object obj ) {
        if ( this == obj ) {
            return true;
        }
        if ( obj == null ) {
            return false;
        }
        if ( getClass() != obj.getClass() ) {
            return false;
        }
        final Pattern other = ( Pattern ) obj;
        if ( !Objects.equals( this.pattern, other.pattern ) ) {
            return false;
        }
        return true;
    }    
}
