import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

/** 
 * The computer will be able to read in/output to a file and store a pattern and 
 * make a prediction based on pattern. Uses a HashMap to hold the pattern and the 
 * number of times the user uses that pattern.
 *
 * @author Chaz Del Prato - CECS 227
 */
public class Computer{
    
    /** Holds the 4 character string pattern (key), and the number of times the 
     * user uses that pattern (value) */
    private HashMap<Pattern, Integer> patterns;
    
    /**
     * Default constructor creates a new HashMap.
     */
    public Computer(){
        patterns = new HashMap<>();
    }
    
    /**
     * The computer will make a prediction to try to beat the user. 
     * The computer will either make a random prediction if there is no pattern 
     * available or it will use the most relevant pattern and try to beat the user. 
     * If the user enters in the same move, the computer will beat them.
     * @param p passes in the pattern the from user input
     * @return returns the computers prediction
     */
    public char makePrediction( String p ){
        Integer patternCount[] = new Integer[3];    //Used to hold the highest value for a pattern
        char compPrediction = 0;                    //Used to hold the prediction of the computer
        int index = 0;                              //Used to hold the index of the array that the 
        int maxCount = 0;                           //Used to determine the highest used pattern
        
        //Checks to see if the left of the pattern passed in is anything greater than or equal to 2
        //If it is, then it will remove the oldest choice and a get ready for the new one
        if( p.length() >= 2 ){
            p = p.substring( 1 );
        }
        
        Pattern firePat = new Pattern( p + "F" );   //Adds the letter F to the pattern
        Pattern grassPat = new Pattern( p + "G" );  //Adds the letter G to the pattern
        Pattern waterPat = new Pattern( p + "W" );  //Adds the letter W to the pattern
        
        //Checks to see if the pattern already exists, if not then it will randomly 
        //create a value between 1-3 and that value will be the computers prediction.
        if( patterns.containsKey( firePat ) || patterns.containsKey( waterPat ) || patterns.containsKey( grassPat ) ){
            
            //Checks to see if the new pattern with the new choice is already a key,
            //then it will add the number of times it has been used into the integer array. 
            //If not it will add a zero into the integer array.
            if( patterns.containsKey( firePat ) ){
                patternCount[0] = patterns.get( firePat );
            }
            else{
                patternCount[0] = 0;
            }
            
            if( patterns.containsKey( waterPat ) ){
                patternCount[1] = patterns.get( waterPat );
            }
            else{
                patternCount[1] = 0;
            }
            
            if( patterns.containsKey( grassPat ) ){
                patternCount[2] = patterns.get( grassPat );
            }
            else{
                patternCount[2] = 0;
            }
            
            //Once the pattern is matched, it will go through the integer array 
            //and determine if the user had used a fire, water, or grass pokemon.
            for( int i = 0; i < patternCount.length; i++ ){
                //Determines which pokemon was used by checking the integer values 
                //of the array and the one that is not a zero is the type of pokemon used.
                if( maxCount <= patternCount[i] ) {
                    maxCount = patternCount[i];
                    index = i;
                }
            }
            
            //Uses the index of the integer array to determine which move the 
            //computer should do to beat the user
            switch( index ){
                //If the index is zero then that mean the user had choosen a fire pokenmon
                case 0:
                    //The computer will use the water pokemon to beat the fire pokemon
                    compPrediction = 'W';
                    break;
                //If the index is two then the user chose a water pokemon            
                case 1:
                    //The computer will use a grass pokemone to beat the water pokemon
                    compPrediction = 'G';
                    break;
                //If the index is two, then the user chose the grass pokemon    
                case 2:
                    //The computer will use a fire pokemone to beat the grass pokemon
                    compPrediction = 'F';
                    break;
                //If the index was to return none of the cases
                default:
                    System.out.println( "Prediction Failed" );
                    break;
            }
        }
        else{
            Random rand = new Random();           //Creates a new random object
            int randNum = rand.nextInt( 3 ) + 1;  //Creates a new random value between 1-3
            
            //Determines what the random value will choose for the computers pokemon
            switch( randNum ){
                //If case 1 then it will return the computer random prediction of the Fire pokemon
                case 1:
                    compPrediction = 'F';
                    break;
                //If case 1 then it will return the computer random prediction of the Water pokemon    
                case 2: 
                    compPrediction = 'W';
                    break;
                //If case 1 then it will return the computer random prediction of the Grass pokemon    
                case 3:
                    compPrediction = 'G';
                    break;
                //If the random number is not in that range then there will be an error    
                default:
                    System.out.println( "Random number error" );
                    break;
            }
        }
        return compPrediction;
    }
    
    /**
     * Stores the pattern into the HashMap.
     * 
     * @param p passes in the pattern to be saved into the HashMap
     */
    public void storePattern( String p ){
        Pattern strPattern = new Pattern( p );  //Used to convert the string into a pattern
        
        //Determines if the pattern already exisits in the HashMap, 
        //if it does then it will increment the number of times the user has used it. 
        //If not it will create a new pattern.
        if( patterns.containsKey( strPattern ) ){
            Integer newInt = patterns.get( strPattern );
            newInt++;
            
            patterns.put( strPattern, newInt );
        }
        else{
            patterns.put( strPattern, 1 );
        }        
    }
    
    /**
     * Saves the HashMap into a txt file.
     * 
     * @param f Passes in the file object
     */
    public void saveMapToFile( File f ){
        try{
            PrintWriter outFile = new PrintWriter( f ); //Used to communicate with the file
            
            //This will go through the entire HashMap and output the key 
            //and value to the file with a comma in between
            for( Pattern key : patterns.keySet() ){
                outFile.print( key.getPattern() + ", " );
                outFile.println( patterns.get( key ) );
            }
            outFile.close();    //closes the output file
        }
        catch( IOException err ){
            //Outputs if there is an error
            System.out.println( "File Failed" );
        }
    }
    
    /**
     * Reads in from a txt file. Saves the data into a HashMap.
     * 
     * @param f passes in the file object
     * @return  returns the string that was used the most by the user
     */
    public String readFile( File f ){
        try{
            Scanner inFile = new Scanner( f );    //used to communitcate with the file
            String line;                          //Used to read the whole line and will split
            String[] splitLine;                   //Holds the split input
            
            //Reads the input file until it is empty
            do{
                line = inFile.nextLine();       //Reads in the entire line
                splitLine = line.split( ", " ); //Splits the line at the comma
                
                Pattern p = new Pattern( splitLine[0] );        //Creates a new pattern 
                Integer i = Integer.parseInt( splitLine[1] );   //creates a new Integer
            
                patterns.put( p, i );   //Stores the pattern and the Integer into the HashMap
            }while( inFile.hasNext() );
            
            inFile.close();     //Closes the input file
        }
        catch( IOException err ){
            //outputs if there is an error
            System.out.println( "File Failed" );
        }
        
        int highest = 0;                        //helps find the highest value
        Pattern tempKey = new Pattern( "" );    //a temp pattern to get returned
        
        //This will go through the entire hashmap and deteremine the key that 
        //has the highest number of uses
        for( Pattern key : patterns.keySet() ){
            //Checks to find the highest value
            if( patterns.get( key ) > highest ){
                highest = patterns.get( key );
                tempKey = key;
            }
        }
        return tempKey.getPattern();
    }       
}